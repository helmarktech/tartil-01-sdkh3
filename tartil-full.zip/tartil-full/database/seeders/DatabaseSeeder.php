<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use App\Models\Guru;
use App\Models\Siswa;
use App\Models\Kelas;
use App\Models\KelasReguler;
use App\Models\Semester;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Truncate semua tabel terlebih dahulu (urut dari child ke parent)
        // Matikan foreign key check sementara
        \DB::statement('SET FOREIGN_KEY_CHECKS=0;');

        \App\Models\JurnalDetail::truncate();
        \App\Models\Jurnal::truncate();
        \App\Models\Absensi::truncate();
        \App\Models\MunaqosyahPendaftaran::truncate();
        \App\Models\UjianMunaqosyah::truncate();
        \App\Models\KenaikanKelasReguler::truncate();
        \App\Models\RiwayatMutasi::truncate();
        \App\Models\PerpindahanKelas::truncate();
        Siswa::truncate();
        Kelas::truncate();
        User::truncate();
        Guru::truncate();
        KelasReguler::truncate();
        Semester::truncate();

        \DB::statement('SET FOREIGN_KEY_CHECKS=1;');

        // 1. Semester
        Semester::create([
            'tahun_ajaran' => '2024/2025',
            'jenis' => 'ganjil',
            'tanggal_mulai' => '2024-07-01',
            'tanggal_selesai' => '2024-12-20',
            'is_aktif' => true,
        ]);
        Semester::create([
            'tahun_ajaran' => '2024/2025',
            'jenis' => 'genap',
            'tanggal_mulai' => '2025-01-01',
            'tanggal_selesai' => '2025-06-20',
            'is_aktif' => false,
        ]);

        // 2. Kelas Reguler (jenjang 1-6, rombel bebas)
        $regularClasses = [
            ['nama' => '1A', 'jenjang' => 1, 'tingkat' => 'A'],
            ['nama' => '1B', 'jenjang' => 1, 'tingkat' => 'B'],
            ['nama' => '2A', 'jenjang' => 2, 'tingkat' => 'A'],
            ['nama' => '2B', 'jenjang' => 2, 'tingkat' => 'B'],
            ['nama' => '3A', 'jenjang' => 3, 'tingkat' => 'A'],
            ['nama' => '4A', 'jenjang' => 4, 'tingkat' => 'A'],
            ['nama' => '5A', 'jenjang' => 5, 'tingkat' => 'A'],
            ['nama' => '6A', 'jenjang' => 6, 'tingkat' => 'A'],
        ];
        foreach ($regularClasses as $rc) {
            KelasReguler::create($rc);
        }

        // 3. Guru
        $guru1 = Guru::create([
            'nama' => 'Ust. Ahmad Ridwan',
            'nip' => '198501012010011001',
            'email' => 'ahmad.ridwan@tartil.id',
            'no_hp' => '081234567890',
            'jenis_kelamin' => 'L',
            'alamat' => 'Jl. Mawar No. 1',
        ]);
        $guru2 = Guru::create([
            'nama' => 'Ustz. Siti Aminah',
            'nip' => '198702022011012002',
            'email' => 'siti.aminah@tartil.id',
            'no_hp' => '082345678901',
            'jenis_kelamin' => 'P',
            'alamat' => 'Jl. Melati No. 2',
        ]);

        // 4. Admin User
        User::create([
            'nama' => 'Administrator',
            'email' => 'admin@tartil.id',
            'password' => Hash::make('admin123'),
            'role' => 'admin',
        ]);

        // Guru Users
        User::create([
            'nama' => $guru1->nama,
            'email' => $guru1->email,
            'password' => Hash::make('guru123'),
            'role' => 'guru',
            'guru_id' => $guru1->id,
        ]);
        User::create([
            'nama' => $guru2->nama,
            'email' => $guru2->email,
            'password' => Hash::make('guru123'),
            'role' => 'guru',
            'guru_id' => $guru2->id,
        ]);

        // 4b. Guru Reguler (pisah dari guru tartil)
        $guruReg1 = \App\Models\GuruReguler::create([
            'nama' => 'Pak Budi Santoso',
            'nip' => '197512121998021001',
            'email' => 'budi.santoso@sekolah.id',
            'no_hp' => '081111222333',
            'jenis_kelamin' => 'L',
            'alamat' => 'Jl. Pendidikan No. 5',
        ]);
        $guruReg2 = \App\Models\GuruReguler::create([
            'nama' => 'Ibu Dewi Kusuma',
            'nip' => '198003032005012001',
            'email' => 'dewi.kusuma@sekolah.id',
            'no_hp' => '082222333444',
            'jenis_kelamin' => 'P',
            'alamat' => 'Jl. Pelajar No. 10',
        ]);

        // Assign guru reguler ke kelas reguler
        KelasReguler::where('nama', '1A')->update(['guru_pengampu_id' => $guruReg1->id, 'keterangan' => 'Kelas unggulan']);
        KelasReguler::where('nama', '2A')->update(['guru_pengampu_id' => $guruReg2->id]);

        // 5. Kelas Tartil
        $kelas1 = Kelas::create([
            'nama' => 'Kelas Tahsin Pemula A',
            'mata_pelajaran' => 'Tahsin Dasar',
            'hari' => 'Senin',
            'jam_mulai' => '15:30',
            'jam_selesai' => '17:00',
            'guru_id' => $guru1->id,
        ]);
        $kelas2 = Kelas::create([
            'nama' => 'Kelas Tahsin Pemula B',
            'mata_pelajaran' => 'Tahsin Dasar',
            'hari' => 'Rabu',
            'jam_mulai' => '15:30',
            'jam_selesai' => '17:00',
            'guru_id' => $guru1->id,
        ]);
        $kelas3 = Kelas::create([
            'nama' => 'Kelas Tartil Lanjutan',
            'mata_pelajaran' => 'Tartil Murottal',
            'hari' => 'Jumat',
            'jam_mulai' => '16:00',
            'jam_selesai' => '17:30',
            'guru_id' => $guru2->id,
        ]);

        // 6. Siswa
        $siswaData = [
            ['nama' => 'Muhammad Farel', 'jk' => 'L', 'reguler' => 1, 'tl' => 'Bandung', 'tgl' => '2012-03-15', 'ayah' => 'Drs. H. Ahmad Sudrajat'],
            ['nama' => 'Aisyah Zahra', 'jk' => 'P', 'reguler' => 1, 'tl' => 'Jakarta', 'tgl' => '2011-07-22', 'ayah' => 'H. Budi Santoso'],
            ['nama' => 'Abdul Rahman', 'jk' => 'L', 'reguler' => 2, 'tl' => 'Surabaya', 'tgl' => '2010-11-05', 'ayah' => 'Drs. H. Candra Wijaya'],
            ['nama' => 'Fatimah Khadijah', 'jk' => 'P', 'reguler' => 2, 'tl' => 'Yogyakarta', 'tgl' => '2011-01-18', 'ayah' => 'H. Dedi Kurniawan'],
            ['nama' => 'Ibrahim Khalil', 'jk' => 'L', 'reguler' => 3, 'tl' => 'Semarang', 'tgl' => '2009-09-30', 'ayah' => 'Prof. H. Eko Prasetyo'],
            ['nama' => 'Khadijah Aminah', 'jk' => 'P', 'reguler' => 3, 'tl' => 'Malang', 'tgl' => '2010-05-12', 'ayah' => 'H. Faisal Rahman'],
            ['nama' => 'Umar Al-Faruq', 'jk' => 'L', 'reguler' => 1, 'tl' => 'Makassar', 'tgl' => '2012-08-25', 'ayah' => 'Drs. H. Gunawan Setyadi'],
            ['nama' => 'Safiyyah Hana', 'jk' => 'P', 'reguler' => 1, 'tl' => 'Palembang', 'tgl' => '2011-12-03', 'ayah' => 'H. Heri Purnomo'],
        ];

        foreach ($siswaData as $i => $s) {
            Siswa::create([
                'nis' => '2024' . str_pad($i + 1, 3, '0', STR_PAD_LEFT),
                'nama' => $s['nama'],
                'no_hp' => '08' . rand(1000000000, 9999999999),
                'password' => Hash::make('2024' . str_pad($i + 1, 3, '0', STR_PAD_LEFT)),
                'jenis_kelamin' => $s['jk'],
                'kelas_reguler_id' => $s['reguler'],
                'kelas_tartil_id' => ($i < 4) ? $kelas1->id : (($i < 6) ? $kelas2->id : $kelas3->id),
                'tanggal_masuk' => '2024-07-01',
                'tempat_lahir' => $s['tl'],
                'tanggal_lahir' => $s['tgl'],
                'nama_ayah' => $s['ayah'],
            ]);
        }

        // 7. Register all active students to the semester with their class snapshot
        $semesterAktif = Semester::aktif()->first();
        if ($semesterAktif) {
            $allSiswa = Siswa::where('status', 'aktif')->get();
            foreach ($allSiswa as $s) {
                \App\Models\SemesterSiswa::create([
                    'semester_id' => $semesterAktif->id,
                    'siswa_id' => $s->id,
                    'kelas_id' => $s->kelas_tartil_id,
                    'kelas_reguler_id' => $s->kelas_reguler_id,
                    'status_siswa' => 'aktif',
                    'keterangan' => 'Registrasi awal',
                ]);
            }

            // Register all kelas tartil to semester
            $allKelas = Kelas::where('status', 'aktif')->get();
            foreach ($allKelas as $k) {
                $jumlah = Siswa::where('kelas_tartil_id', $k->id)->where('status', 'aktif')->count();
                \App\Models\SemesterKelas::create([
                    'semester_id' => $semesterAktif->id,
                    'kelas_id' => $k->id,
                    'jumlah_siswa' => $jumlah,
                    'keterangan' => 'Kelas aktif',
                ]);
            }
        }

        $this->command->info('Seed berhasil!');
        $this->command->info('Admin: admin@tartil.id / admin123');
        $this->command->info('Guru: ahmad.ridwan@tartil.id / guru123');
        $this->command->info('Siswa login: NIS + No HP (lihat database)');
    }
}
