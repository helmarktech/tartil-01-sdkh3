<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('semesters', function (Blueprint $table) {
            // Kolom status ditangani oleh migration 000022
            // Index untuk validasi TA + jenis
            $table->index(['tahun_ajaran', 'jenis']);
        });
    }

    public function down(): void
    {
        Schema::table('semesters', function (Blueprint $table) {
            $table->dropIndex(['tahun_ajaran', 'jenis']);
        });
    }
};
