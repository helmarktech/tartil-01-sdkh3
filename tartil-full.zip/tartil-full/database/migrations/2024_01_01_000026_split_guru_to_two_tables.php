<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Migration ini hanya untuk UPGRADE existing database.
        // Di fresh install, tabel guru_tartils sudah dibuat oleh 000003,
        // jadi skip semua operasi rename.
        if (!Schema::hasTable('gurus')) {
            // Fresh install: gurus tidak ada berarti guru_tartils sudah dibuat oleh 000003
            // Tidak perlu apa-apa
            return;
        }

        // ============================================
        // STEP 1: Drop all FK constraints referencing gurus
        // ============================================

        Schema::table('kelas', function (Blueprint $table) {
            try { $table->dropForeign(['guru_id']); } catch (\Throwable $e) {}
        });

        Schema::table('users', function (Blueprint $table) {
            try { $table->dropForeign(['guru_id']); } catch (\Throwable $e) {}
        });

        Schema::table('jurnals', function (Blueprint $table) {
            try { $table->dropForeign(['guru_id']); } catch (\Throwable $e) {}
        });

        Schema::table('perpindahan_kelas', function (Blueprint $table) {
            try { $table->dropForeign(['guru_tujuan_id']); } catch (\Throwable $e) {}
            try { $table->dropForeign(['pengaju_id']); } catch (\Throwable $e) {}
            try { $table->dropForeign(['approved_by']); } catch (\Throwable $e) {}
        });

        Schema::table('ujian_munaqosyahs', function (Blueprint $table) {
            try { $table->dropForeign(['diajukan_oleh']); } catch (\Throwable $e) {}
        });

        Schema::table('kelas_regulers', function (Blueprint $table) {
            try { $table->dropForeign(['guru_pengampu_id']); } catch (\Throwable $e) {}
        });

        // ============================================
        // STEP 2: Rename gurus → guru_tartils
        // ============================================
        Schema::rename('gurus', 'guru_tartils');

        // ============================================
        // STEP 3: Recreate FKs referencing guru_tartils
        // ============================================

        Schema::table('kelas', function (Blueprint $table) {
            if (Schema::hasColumn('kelas', 'guru_id')) {
                $table->foreign('guru_id')->references('id')->on('guru_tartils')->nullOnDelete();
            }
        });

        Schema::table('users', function (Blueprint $table) {
            if (Schema::hasColumn('users', 'guru_id')) {
                $table->foreign('guru_id')->references('id')->on('guru_tartils')->nullOnDelete();
            }
        });

        Schema::table('jurnals', function (Blueprint $table) {
            if (Schema::hasColumn('jurnals', 'guru_id')) {
                $table->foreign('guru_id')->references('id')->on('guru_tartils')->cascadeOnDelete();
            }
        });

        Schema::table('perpindahan_kelas', function (Blueprint $table) {
            if (Schema::hasColumn('perpindahan_kelas', 'guru_tujuan_id')) {
                $table->foreign('guru_tujuan_id')->references('id')->on('guru_tartils')->nullOnDelete();
            }
        });

        Schema::table('ujian_munaqosyahs', function (Blueprint $table) {
            if (Schema::hasColumn('ujian_munaqosyahs', 'diajukan_oleh')) {
                $table->foreign('diajukan_oleh')->references('id')->on('guru_tartils')->nullOnDelete();
            }
        });

        // ============================================
        // STEP 4: Create guru_regulers table
        // ============================================
        if (!Schema::hasTable('guru_regulers')) {
            Schema::create('guru_regulers', function (Blueprint $table) {
                $table->id();
                $table->string('nama', 100);
                $table->string('nip', 30)->nullable()->unique();
                $table->string('email', 100)->unique();
                $table->string('no_hp', 15);
                $table->enum('jenis_kelamin', ['L', 'P']);
                $table->text('alamat')->nullable();
                $table->boolean('is_aktif')->default(true);
                $table->softDeletes();
                $table->timestamps();
            });
        }

        // ============================================
        // STEP 5: Update kelas_regulers FK to guru_regulers
        // ============================================
        Schema::table('kelas_regulers', function (Blueprint $table) {
            if (Schema::hasColumn('kelas_regulers', 'guru_pengampu_id')) {
                $table->foreign('guru_pengampu_id')->references('id')->on('guru_regulers')->nullOnDelete();
            }
        });
    }

    public function down(): void
    {
        if (!Schema::hasTable('guru_tartils')) {
            return;
        }

        Schema::table('kelas', function (Blueprint $table) {
            try { $table->dropForeign(['guru_id']); } catch (\Throwable $e) {}
        });
        Schema::table('users', function (Blueprint $table) {
            try { $table->dropForeign(['guru_id']); } catch (\Throwable $e) {}
        });
        Schema::table('jurnals', function (Blueprint $table) {
            try { $table->dropForeign(['guru_id']); } catch (\Throwable $e) {}
        });
        Schema::table('perpindahan_kelas', function (Blueprint $table) {
            try { $table->dropForeign(['guru_tujuan_id']); } catch (\Throwable $e) {}
        });
        Schema::table('ujian_munaqosyahs', function (Blueprint $table) {
            try { $table->dropForeign(['diajukan_oleh']); } catch (\Throwable $e) {}
        });
        Schema::table('kelas_regulers', function (Blueprint $table) {
            try { $table->dropForeign(['guru_pengampu_id']); } catch (\Throwable $e) {}
        });

        Schema::dropIfExists('guru_regulers');
        Schema::rename('guru_tartils', 'gurus');

        Schema::table('kelas', function (Blueprint $table) {
            $table->foreign('guru_id')->references('id')->on('gurus')->nullOnDelete();
        });
        Schema::table('users', function (Blueprint $table) {
            $table->foreign('guru_id')->references('id')->on('gurus')->nullOnDelete();
        });
        Schema::table('jurnals', function (Blueprint $table) {
            $table->foreign('guru_id')->references('id')->on('gurus')->cascadeOnDelete();
        });
        Schema::table('perpindahan_kelas', function (Blueprint $table) {
            $table->foreign('guru_tujuan_id')->references('id')->on('gurus')->nullOnDelete();
        });
        Schema::table('ujian_munaqosyahs', function (Blueprint $table) {
            $table->foreign('diajukan_oleh')->references('id')->on('gurus')->nullOnDelete();
        });
    }
};
