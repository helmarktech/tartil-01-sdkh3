<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('kelas_regulers', function (Blueprint $table) {
            // Ubah jenjang dari enum ke integer (1-6)
            if (Schema::hasColumn('kelas_regulers', 'jenjang')) {
                $table->integer('jenjang')->change();
            }
            // Ubah tingkat dari integer ke string (rombel bebas)
            if (Schema::hasColumn('kelas_regulers', 'tingkat')) {
                $table->string('tingkat', 20)->change();
            }
        });
    }

    public function down(): void
    {
        Schema::table('kelas_regulers', function (Blueprint $table) {
            $table->enum('jenjang', ['MI', 'MTs', 'MA', 'SMP', 'SMA'])->change();
            $table->integer('tingkat')->change();
        });
    }
};
