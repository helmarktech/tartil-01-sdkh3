<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Rapor Kelas {{ $kelas->nama }}</title>
    <style>
        body { font-family: 'Arial', sans-serif; font-size: 11px; line-height: 1.5; color: #333; }
        .header { text-align: center; border-bottom: 3px double #6B5E51; padding-bottom: 15px; margin-bottom: 20px; }
        .header h1 { font-size: 18px; margin: 0; color: #6B5E51; }
        .header h2 { font-size: 14px; margin: 5px 0 0; font-weight: normal; }
        .info { margin-bottom: 20px; font-size: 12px; }
        .info strong { color: #6B5E51; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        th { background: #E9E6E1; padding: 8px; text-align: center; font-size: 10px; border: 1px solid #D9D5D0; }
        td { padding: 6px 8px; border: 1px solid #D9D5D0; text-align: center; }
        td:first-child, td:nth-child(2) { text-align: left; }
        .predikat-a { background: #E9F0E9; color: #5A7D5A; font-weight: bold; }
        .predikat-b { background: #E9EEF0; color: #5A7A8A; font-weight: bold; }
        .predikat-c { background: #F0ECE9; color: #8A7A6B; font-weight: bold; }
        .predikat-d { background: #F0E9E9; color: #A85A52; font-weight: bold; }
        .predikat-e { background: #F0E9F0; color: #8A5A8A; font-weight: bold; }
        .footer { margin-top: 20px; text-align: right; font-size: 10px; color: #96918D; }
    </style>
</head>
<body>
    <div class="header">
        <h1>RAPOR KELAS TARTIL</h1>
        <h2>Semester {{ ucfirst($semester->jenis) }} Tahun Ajaran {{ $semester->tahun_ajaran }}</h2>
    </div>

    <div class="info">
        <strong>Kelas:</strong> {{ $kelas->nama }} | 
        <strong>Mata Pelajaran:</strong> {{ $kelas->mata_pelajaran }} | 
        <strong>Guru:</strong> {{ $kelas->guru->nama ?? '-' }} | 
        <strong>Jumlah Siswa:</strong> {{ count($dataRapor) }}
    </div>

    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Siswa</th>
                <th>NIS</th>
                <th>B</th>
                <th>C</th>
                <th>K</th>
                <th>Rata</th>
                <th>Predikat</th>
                <th>Hadir</th>
                <th>Alpha</th>
            </tr>
        </thead>
        <tbody>
            @foreach($dataRapor as $i => $r)
            @php 
                $p = substr($r['predikat'], 0, 1);
                $predClass = match($p) { 'A' => 'predikat-a', 'B' => 'predikat-b', 'C' => 'predikat-c', 'D' => 'predikat-d', default => 'predikat-e' };
            @endphp
            <tr>
                <td>{{ $i+1 }}</td>
                <td>{{ $r['siswa']->nama }}</td>
                <td>{{ $r['siswa']->nis }}</td>
                <td>{{ $r['rata_b'] }}</td>
                <td>{{ $r['rata_c'] }}</td>
                <td>{{ $r['rata_k'] }}</td>
                <td><strong>{{ $r['rata_akhir'] }}</strong></td>
                <td class="{{ $predClass }}">{{ $p }}</td>
                <td>{{ $r['absensi']['Hadir'] }}</td>
                <td>{{ $r['absensi']['Alpha'] }}</td>
            </tr>
            @endforeach
        </tbody>
    </table>

    <div class="footer">
        Dicetak pada {{ now()->format('d F Y H:i') }}
    </div>
</body>
</html>
