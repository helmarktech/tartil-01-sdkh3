<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Rapor {{ $siswa->nama }}</title>
    <style>
        body { font-family: 'Arial', sans-serif; font-size: 12px; line-height: 1.6; color: #333; }
        .header { text-align: center; border-bottom: 3px double #6B5E51; padding-bottom: 15px; margin-bottom: 20px; }
        .header h1 { font-size: 18px; margin: 0; color: #6B5E51; }
        .header h2 { font-size: 14px; margin: 5px 0 0; font-weight: normal; }
        .info-table { width: 100%; margin-bottom: 20px; }
        .info-table td { padding: 4px 8px; vertical-align: top; }
        .info-table .label { font-weight: bold; width: 30%; color: #6B5E51; }
        .section-title { font-size: 14px; font-weight: bold; color: #6B5E51; border-bottom: 1px solid #D9D5D0; padding-bottom: 5px; margin: 20px 0 10px; }
        table.data { width: 100%; border-collapse: collapse; margin-bottom: 15px; }
        table.data th { background: #E9E6E1; padding: 8px; text-align: left; font-size: 11px; border: 1px solid #D9D5D0; }
        table.data td { padding: 8px; border: 1px solid #D9D5D0; }
        .summary-box { background: #F6F4F1; padding: 15px; border-radius: 8px; border: 1px solid #D9D5D0; }
        .nilai-grid { display: inline-block; width: 100%; }
        .nilai-item { float: left; width: 25%; text-align: center; padding: 10px; box-sizing: border-box; }
        .nilai-value { font-size: 28px; font-weight: bold; color: #6B5E51; }
        .nilai-label { font-size: 11px; color: #96918D; margin-top: 5px; }
        .predikat { font-size: 18px; font-weight: bold; text-align: center; padding: 10px; background: #E9E6E1; border-radius: 8px; margin-top: 10px; }
        .footer { margin-top: 30px; text-align: right; font-size: 11px; color: #96918D; }
        .clear { clear: both; }
    </style>
</head>
<body>
    <div class="header">
        <h1>RAPOR PENILAIAN TARTIL</h1>
        <h2>Semester {{ ucfirst($semester->jenis) }} Tahun Ajaran {{ $semester->tahun_ajaran }}</h2>
    </div>

    <table class="info-table">
        <tr><td class="label">NIS</td><td>: {{ $siswa->nis }}</td><td class="label">Kelas Reguler</td><td>: {{ $siswa->kelasReguler->nama }}</td></tr>
        <tr><td class="label">Nama</td><td>: {{ $siswa->nama }}</td><td class="label">Kelas Tartil</td><td>: {{ $kelas->nama }}</td></tr>
        <tr><td class="label">Guru</td><td>: {{ $kelas->guru->nama ?? '-' }}</td><td class="label">Mata Pelajaran</td><td>: {{ $kelas->mata_pelajaran }}</td></tr>
    </table>

    <div class="section-title">Ringkasan Penilaian</div>
    <div class="nilai-grid">
        <div class="nilai-item">
            <div class="nilai-value">{{ $rapor['rata_b'] }}</div>
            <div class="nilai-label">Bacaan (B)</div>
        </div>
        <div class="nilai-item">
            <div class="nilai-value">{{ $rapor['rata_c'] }}</div>
            <div class="nilai-label">Catatan (C)</div>
        </div>
        <div class="nilai-item">
            <div class="nilai-value">{{ $rapor['rata_k'] }}</div>
            <div class="nilai-label">Keterampilan (K)</div>
        </div>
        <div class="nilai-item">
            <div class="nilai-value">{{ $rapor['rata_akhir'] }}</div>
            <div class="nilai-label">Nilai Akhir</div>
        </div>
        <div class="clear"></div>
    </div>

    <div class="predikat">Predikat: {{ $rapor['predikat'] }}</div>

    <div class="section-title">Detail Penilaian ({{ $rapor['jumlah_penilaian'] }} x pertemuan)</div>
    <table class="data">
        <thead>
            <tr>
                <th>No</th>
                <th>Tanggal</th>
                <th>Surat</th>
                <th>Ayat</th>
                <th>B</th>
                <th>C</th>
                <th>K</th>
                <th>Rata</th>
            </tr>
        </thead>
        <tbody>
            @foreach($rapor['details'] as $i => $d)
            <tr>
                <td>{{ $i+1 }}</td>
                <td>{{ $d->jurnal->tanggal->format('d/m/Y') }}</td>
                <td>{{ $d->jurnal->surat }}</td>
                <td>{{ $d->jurnal->ayat }}</td>
                <td>{{ $d->nilai_b }}</td>
                <td>{{ $d->nilai_c }}</td>
                <td>{{ $d->nilai_k }}</td>
                <td>{{ $d->nilai_akhir }}</td>
            </tr>
            @endforeach
        </tbody>
    </table>

    <div class="section-title">Kehadiran</div>
    <div class="summary-box">
        <table class="info-table">
            <tr>
                <td class="label">Hadir</td><td>: {{ $rapor['absensi']['Hadir'] }} kali</td>
                <td class="label">Sakit</td><td>: {{ $rapor['absensi']['Sakit'] }} kali</td>
            </tr>
            <tr>
                <td class="label">Izin</td><td>: {{ $rapor['absensi']['Izin'] }} kali</td>
                <td class="label">Alpha</td><td>: {{ $rapor['absensi']['Alpha'] }} kali</td>
            </tr>
            <tr>
                <td class="label">Total Pertemuan</td><td>: {{ $rapor['total_pertemuan'] }} kali</td>
                <td class="label">Persentase Hadir</td><td>: {{ $rapor['persentase_hadir'] }}%</td>
            </tr>
        </table>
    </div>

    <div class="footer">
        Dicetak pada {{ now()->format('d F Y H:i') }}
    </div>
</body>
</html>
