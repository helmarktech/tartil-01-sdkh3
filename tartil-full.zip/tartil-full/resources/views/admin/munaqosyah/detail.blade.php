@extends('layouts.admin')
@section('title', 'Detail Ujian Munaqosyah')

@section('content')
<div>
    {{-- Header --}}
    <div class="page-header" style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 12px;">
        <div>
            <h1 class="page-title-display">{{ $munaqosyah->nama }}</h1>
            <p class="page-subtitle">{{ ucfirst($munaqosyah->tingkat) }} - {{ $munaqosyah->tanggal_ujian ? date('d/m/Y', strtotime($munaqosyah->tanggal_ujian)) : '-' }}</p>
        </div>
        <div style="display: flex; gap: 8px;">
            <a href="{{ route('admin.munaqosyah.daftar', ['munaqosyah_id' => $munaqosyah->id]) }}" class="btn-tartil">Daftar Siswa Ujian</a>
            <a href="{{ route('admin.munaqosyah.index') }}" class="btn-tartil-outline">Kembali</a>
        </div>
    </div>

    {{-- Info Ujian --}}
    <div class="card-tartil" style="margin-bottom: 20px;">
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px;">
            <div>
                <div class="form-label" style="margin-bottom: 4px;">Nama Ujian</div>
                <div style="font-weight: 600; color: var(--text-primary);">{{ $munaqosyah->nama }}</div>
            </div>
            <div>
                <div class="form-label" style="margin-bottom: 4px;">Tingkat</div>
                <span class="badge-subject">{{ ucfirst($munaqosyah->tingkat) }}</span>
            </div>
            <div>
                <div class="form-label" style="margin-bottom: 4px;">Tanggal Ujian</div>
                <div style="color: var(--text-primary);">{{ $munaqosyah->tanggal_ujian ? date('d/m/Y', strtotime($munaqosyah->tanggal_ujian)) : '-' }}</div>
            </div>
            <div>
                <div class="form-label" style="margin-bottom: 4px;">Semester</div>
                <div style="color: var(--text-primary);">{{ $munaqosyah->semester->nama ?? '-' }}</div>
            </div>
            <div>
                <div class="form-label" style="margin-bottom: 4px;">Status</div>
                @if($munaqosyah->status == 'pengajuan')
                    <span class="badge-warning">Pengajuan</span>
                @elseif($munaqosyah->status == 'disetujui')
                    <span class="badge-success">Disetujui</span>
                @elseif($munaqosyah->status == 'berlangsung')
                    <span class="badge-info">Berlangsung</span>
                @elseif($munaqosyah->status == 'selesai')
                    <span class="badge-subject">Selesai</span>
                @else
                    <span class="badge-error">Ditolak</span>
                @endif
            </div>
            <div>
                <div class="form-label" style="margin-bottom: 4px;">Dibuat Oleh</div>
                <div style="color: var(--text-primary);">{{ $munaqosyah->pengaju->nama ?? '-' }}</div>
            </div>
        </div>
    </div>

    {{-- Statistik Ringkasan --}}
    <h3 style="font-size: 16px; margin: 0 0 12px; color: var(--text-primary); font-weight: 600;">Statistik Pendaftar</h3>
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(130px, 1fr)); gap: 12px; margin-bottom: 24px;">
        <div class="card-tartil" style="text-align: center;">
            <div style="font-size: 28px; font-weight: 700; color: var(--accent);">{{ $munaqosyah->total_pendaftar }}</div>
            <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">Total Peserta</div>
        </div>
        @if($munaqosyah->total_pending > 0)
        <div class="card-tartil" style="text-align: center; cursor: pointer;" onclick="window.location='{{ route('admin.munaqosyah.approval.index') }}'">
            <div style="font-size: 28px; font-weight: 700; color: #D4A373;">{{ $munaqosyah->total_pending }}</div>
            <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">Menunggu Approval</div>
            <div style="font-size: 10px; color: var(--accent); margin-top: 4px;">Klik untuk lihat</div>
        </div>
        @endif
        <div class="card-tartil" style="text-align: center;">
            <div style="font-size: 28px; font-weight: 700; color: #5A7D5A;">{{ $munaqosyah->total_lulus }}</div>
            <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">Lulus</div>
        </div>
        <div class="card-tartil" style="text-align: center;">
            <div style="font-size: 28px; font-weight: 700; color: #A85A52;">{{ $munaqosyah->total_tidak_lulus }}</div>
            <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">Tidak Lulus</div>
        </div>
        <div class="card-tartil" style="text-align: center;">
            <div style="font-size: 28px; font-weight: 700; color: var(--text-secondary);">{{ $munaqosyah->total_menunggu }}</div>
            <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">Menunggu Penilaian</div>
        </div>
    </div>

    {{-- Peserta Overview (hanya nama & status, tanpa aksi) --}}
    {{-- Hanya tampilkan siswa yang sudah terdaftar, bukan pending --}}
    @php
        $pesertaAktif = $munaqosyah->pendaftarans()->with('siswa.kelasReguler', 'siswa.kelasTartil')
            ->where('status', '!=', 'pending')
            ->orderBy('status')
            ->orderBy('created_at')
            ->get();
    @endphp
    @if($pesertaAktif->count() > 0)
    <h3 style="font-size: 16px; margin: 0 0 12px; color: var(--text-primary); font-weight: 600;">Daftar Peserta</h3>
    <div class="card-tartil table-responsive">
        <table class="table-tartil">
            <thead>
                <tr>
                    <th style="width: 40px;">No</th>
                    <th>NIS</th>
                    <th>Nama Siswa</th>
                    <th>Kelas Reguler</th>
                    <th>Kelas Tartil</th>
                    <th>Status</th>
                    <th>Nilai</th>
                </tr>
            </thead>
            <tbody>
                @foreach($pesertaAktif as $i => $p)
                <tr>
                    <td style="text-align: center;">{{ $i + 1 }}</td>
                    <td>{{ $p->siswa->nis ?? '-' }}</td>
                    <td style="font-weight: 500;">{{ $p->siswa->nama ?? '-' }}</td>
                    <td>{{ $p->siswa->kelasReguler->nama ?? '-' }}</td>
                    <td>{{ $p->siswa->kelasTartil->nama ?? '-' }}</td>
                    <td>
                        @if($p->status == 'terdaftar')
                            <span class="badge-warning">Terdaftar</span>
                        @elseif($p->status == 'lulus')
                            <span class="badge-success">Lulus</span>
                        @elseif($p->status == 'tidak_lulus')
                            <span class="badge-error">Tidak Lulus</span>
                        @else
                            <span class="badge-muted">{{ $p->status }}</span>
                        @endif
                    </td>
                    <td>{{ $p->nilai ?? '-' }}</td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
    @else
    <div class="card-tartil" style="text-align: center; padding: 40px;">
        @if($munaqosyah->total_pending > 0)
            <div style="font-size: 14px; color: #D4A373; font-weight: 500;">{{ $munaqosyah->total_pending }} siswa menunggu approval.</div>
            <a href="{{ route('admin.munaqosyah.approval.index') }}" class="btn-tartil" style="margin-top: 12px;">Lihat Approval</a>
        @else
            <div style="font-size: 14px; color: var(--text-muted);">Belum ada peserta terdaftar.</div>
            <a href="{{ route('admin.munaqosyah.daftar', ['munaqosyah_id' => $munaqosyah->id]) }}" class="btn-tartil" style="margin-top: 12px;">Daftarkan Siswa</a>
        @endif
    </div>
    @endif
</div>
@endsection
