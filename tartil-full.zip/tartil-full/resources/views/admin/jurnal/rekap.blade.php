@extends('layouts.admin')
@section('title', 'Rekap Jurnal Admin')

@section('content')
<div>
    <div class="page-header" style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 12px;">
        <div>
            <h1 class="page-title-display">Rekap Jurnal</h1>
            <p class="page-subtitle">Lihat rekap jurnal seluruh kelas</p>
        </div>
    </div>

    {{-- Filter --}}
    <div class="card-tartil" style="margin-bottom: 16px; padding: 16px;">
        <form method="GET" class="form-inline" style="gap: 12px; flex-wrap: wrap;">
            <div class="form-group" style="margin-bottom: 0;">
                <label class="form-label" style="font-size: 12px;">Semester</label>
                <select name="semester_id" class="form-input" onchange="this.form.submit()" style="min-width: 180px;">
                    <option value="">-- Pilih Semester --</option>
                    @foreach($semesters as $s)
                    <option value="{{ $s->id }}" {{ $semesterId == $s->id ? 'selected' : '' }}>{{ $s->nama }}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group" style="margin-bottom: 0;">
                <label class="form-label" style="font-size: 12px;">Kelas</label>
                <select name="kelas_id" class="form-input" onchange="this.form.submit()" style="min-width: 180px;">
                    <option value="">-- Pilih Kelas --</option>
                    @foreach($kelasList as $k)
                    <option value="{{ $k->id }}" {{ $kelasId == $k->id ? 'selected' : '' }}>{{ $k->nama }}</option>
                    @endforeach
                </select>
            </div>
        </form>
    </div>

    @if($rekap && $rekap->count() > 0)
    @foreach($rekap as $siswaId => $bulanRekaps)
    @php $siswaNama = $bulanRekaps->first()->siswa->nama ?? '-'; @endphp
    <h3 style="font-size: 15px; margin: 20px 0 8px; color: var(--text-primary); font-weight: 600;">{{ $siswaNama }}</h3>
    <div class="card-tartil table-responsive" style="margin-bottom: 16px;">
        <table class="table-tartil">
            <thead>
                <tr>
                    <th>Bulan</th>
                    <th>Hadir</th>
                    <th>Izin</th>
                    <th>Sakit</th>
                    <th>Alpa</th>
                    <th>%Hadir</th>
                    <th>B</th>
                    <th>C</th>
                    <th>K</th>
                    <th>Rata-rata</th>
                </tr>
            </thead>
            <tbody>
                @foreach($bulanRekaps as $r)
                <tr>
                    <td>{{ substr($r->bulan, 0, 4) . '-' . substr($r->bulan, 4, 2) }}</td>
                    <td>{{ $r->total_hadir }}</td>
                    <td>{{ $r->total_izin }}</td>
                    <td>{{ $r->total_sakit }}</td>
                    <td>{{ $r->total_alpa }}</td>
                    <td>
                        <span class="{{ $r->persenHadir() >= 80 ? 'badge-success' : ($r->persenHadir() >= 60 ? 'badge-warning' : 'badge-error') }}" style="font-size: 11px;">
                            {{ $r->persenHadir() }}%
                        </span>
                    </td>
                    <td>{{ $r->count_b }}</td>
                    <td>{{ $r->count_c }}</td>
                    <td>{{ $r->count_k }}</td>
                    <td>
                        @if($r->rata_rata !== null)
                            @if($r->rata_rata >= 0.85)
                                <span class="badge-success" style="font-size: 11px;">Baik</span>
                            @elseif($r->rata_rata >= 0.60)
                                <span class="badge-warning" style="font-size: 11px;">Cukup</span>
                            @else
                                <span class="badge-error" style="font-size: 11px;">Kurang</span>
                            @endif
                        @else
                            <span style="color: var(--text-muted);">-</span>
                        @endif
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
    @endforeach
    @elseif($semesterId && $kelasId)
    <div class="card-tartil" style="text-align: center; padding: 40px;">
        <div style="color: var(--text-muted);">Belum ada data rekap untuk semester dan kelas ini.</div>
    </div>
    @endif
</div>
@endsection
