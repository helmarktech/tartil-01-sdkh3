@extends('layouts.siswa')
@section('title', 'Dashboard')

@section('content')
<div>
    <div class="page-header">
        <h1 class="page-title-display" style="font-size: 22px;">Dashboard</h1>
    </div>

    @if($semester)
    <div class="card-tartil" style="padding: 16px; margin-bottom: 16px;">
        <div style="font-size: 13px; color: var(--text-muted);">Semester Aktif</div>
        <div style="font-weight: 600; color: var(--text-primary);">{{ $semester->tahun_ajaran }} {{ ucfirst($semester->jenis) }}</div>
    </div>
    @endif

    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(130px, 1fr)); gap: 10px; margin-bottom: 16px;">
        <div class="stat-card" style="padding: 14px;">
            <div style="font-size: 11px; color: var(--text-muted); text-transform: uppercase;">Penilaian</div>
            <div class="stat-value" style="font-size: 22px; margin-top: 6px;">{{ $nilaiSemester->count() }}</div>
        </div>
        <div class="stat-card" style="padding: 14px;">
            <div style="font-size: 11px; color: var(--text-muted); text-transform: uppercase;">Rata-rata B</div>
            <div class="stat-value" style="font-size: 22px; margin-top: 6px;">{{ $nilaiSemester->count() > 0 ? round($nilaiSemester->avg('nilai_b'), 1) : 0 }}</div>
        </div>
        <div class="stat-card" style="padding: 14px;">
            <div style="font-size: 11px; color: var(--text-muted); text-transform: uppercase;">Rata-rata C</div>
            <div class="stat-value" style="font-size: 22px; margin-top: 6px;">{{ $nilaiSemester->count() > 0 ? round($nilaiSemester->avg('nilai_c'), 1) : 0 }}</div>
        </div>
        <div class="stat-card" style="padding: 14px;">
            <div style="font-size: 11px; color: var(--text-muted); text-transform: uppercase;">Rata-rata K</div>
            <div class="stat-value" style="font-size: 22px; margin-top: 6px;">{{ $nilaiSemester->count() > 0 ? round($nilaiSemester->avg('nilai_k'), 1) : 0 }}</div>
        </div>
    </div>

    <div class="card-tartil" style="margin-bottom: 16px;">
        <div style="padding: 14px 16px; border-bottom: 1px solid var(--border);">
            <h2 style="font-size: 14px; font-weight: 600; margin: 0;">Absensi</h2>
        </div>
        <div style="display: grid; grid-template-columns: repeat(4, 1fr); text-align: center;">
            <div style="padding: 12px;">
                <div style="font-size: 20px; font-weight: 700; color: #5A7D5A;">{{ $absensiStats['Hadir'] }}</div>
                <div style="font-size: 10px; color: var(--text-muted);">Hadir</div>
            </div>
            <div style="padding: 12px;">
                <div style="font-size: 20px; font-weight: 700; color: #C4953A;">{{ $absensiStats['Sakit'] }}</div>
                <div style="font-size: 10px; color: var(--text-muted);">Sakit</div>
            </div>
            <div style="padding: 12px;">
                <div style="font-size: 20px; font-weight: 700; color: #5A7A8A;">{{ $absensiStats['Izin'] }}</div>
                <div style="font-size: 10px; color: var(--text-muted);">Izin</div>
            </div>
            <div style="padding: 12px;">
                <div style="font-size: 20px; font-weight: 700; color: #A85A52;">{{ $absensiStats['Alpha'] }}</div>
                <div style="font-size: 10px; color: var(--text-muted);">Alpha</div>
            </div>
        </div>
    </div>

    <div class="card-tartil">
        <div style="padding: 14px 16px; border-bottom: 1px solid var(--border);">
            <h2 style="font-size: 14px; font-weight: 600; margin: 0;">Info Kelas</h2>
        </div>
        <div style="padding: 14px 16px;">
            <div style="display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid var(--border);">
                <span style="color: var(--text-muted); font-size: 13px;">Kelas Reguler</span>
                <span style="font-weight: 500; font-size: 13px;">{{ $siswa->kelasReguler->nama ?? '-' }}</span>
            </div>
            <div style="display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid var(--border);">
                <span style="color: var(--text-muted); font-size: 13px;">Kelas Tartil</span>
                <span style="font-weight: 500; font-size: 13px;">{{ $siswa->kelasTartil->nama ?? '-' }}</span>
            </div>
            <div style="display: flex; justify-content: space-between; padding: 8px 0;">
                <span style="color: var(--text-muted); font-size: 13px;">Status</span>
                <span class="badge-subject" style="background: #E9F0E9; color: #5A7D5A;">{{ ucfirst($siswa->status) }}</span>
            </div>
        </div>
    </div>
</div>
@endsection
