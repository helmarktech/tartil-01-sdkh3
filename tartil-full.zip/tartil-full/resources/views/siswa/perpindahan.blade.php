@extends('layouts.siswa')
@section('title', 'Riwayat Kelas')

@section('content')
<div>
    <div class="page-header">
        <h1 class="page-title-display" style="font-size: 22px;">Riwayat Kelas</h1>
        <p class="page-subtitle">Track record perpindahan kelas tartil</p>
    </div>

    <div class="card-tartil">
        @forelse($perpindahans as $p)
        <div style="padding: 16px 20px; border-bottom: 1px solid var(--border);">
            <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                <div>
                    <div style="font-weight: 500; font-size: 14px;">{{ $p->kelasLama->nama }} → {{ $p->kelasBaru->nama }}</div>
                    <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">
                        {{ $p->semester->tahun_ajaran }} {{ ucfirst($p->semester->jenis) }}
                    </div>
                    <div style="font-size: 12px; color: var(--text-muted); margin-top: 2px;">
                        Alasan: {{ $p->alasan }}
                    </div>
                </div>
                <span class="badge-subject" style="background: {{ $p->status == 'disetujui' ? '#E9F0E9' : ($p->status == 'pending' ? '#F0ECE9' : '#F0E9E9') }}; color: {{ $p->status == 'disetujui' ? '#5A7D5A' : ($p->status == 'pending' ? '#8A7A6B' : '#A85A52') }};">
                    {{ ucfirst($p->status) }}
                </span>
            </div>
            @if($p->catatan)
            <div style="margin-top: 8px; font-size: 12px; color: var(--text-secondary); font-style: italic;">
                Catatan: {{ $p->catatan }}
            </div>
            @endif
        </div>
        @empty
        <div style="padding: 40px; text-align: center; color: var(--text-muted);">Belum ada riwayat perpindahan kelas.</div>
        @endforelse
    </div>
    {{ $perpindahans->links() }}
</div>
@endsection
