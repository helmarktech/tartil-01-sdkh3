@extends('layouts.siswa')
@section('title', 'Nilai')

@section('content')
<div>
    <div class="page-header">
        <h1 class="page-title-display" style="font-size: 22px;">Nilai</h1>
        <p class="page-subtitle">Riwayat penilaian tartil</p>
    </div>

    <div class="card-tartil" style="padding: 12px 16px; margin-bottom: 16px;">
        <form method="GET" action="{{ route('siswa.nilai') }}" style="margin: 0;">
            <select name="semester" onchange="this.form.submit()" style="width: 100%; padding: 10px 12px; border-radius: 10px; border: 1px solid var(--border); font-size: 14px; font-family: 'Inter', sans-serif;">
                @foreach($semesters as $s)
                <option value="{{ $s->id }}" {{ $semesterId == $s->id ? 'selected' : '' }}>{{ $s->tahun_ajaran }} {{ ucfirst($s->jenis) }} {{ $s->is_aktif ? '(Aktif)' : '' }}</option>
                @endforeach
            </select>
        </form>
    </div>

    @if($nilais->count() > 0)
    @php
        $avgB = round($nilais->avg('nilai_b'), 1);
        $avgC = round($nilais->avg('nilai_c'), 1);
        $avgK = round($nilais->avg('nilai_k'), 1);
        $avgTotal = round(($avgB + $avgC + $avgK) / 3, 1);
    @endphp
    <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px; margin-bottom: 16px;">
        <div class="stat-card" style="padding: 12px; text-align: center;">
            <div style="font-size: 20px; font-weight: 700; color: var(--accent); font-family: 'DM Serif Display', serif;">{{ $avgB }}</div>
            <div style="font-size: 10px; color: var(--text-muted);">Rata B</div>
        </div>
        <div class="stat-card" style="padding: 12px; text-align: center;">
            <div style="font-size: 20px; font-weight: 700; color: var(--accent); font-family: 'DM Serif Display', serif;">{{ $avgC }}</div>
            <div style="font-size: 10px; color: var(--text-muted);">Rata C</div>
        </div>
        <div class="stat-card" style="padding: 12px; text-align: center;">
            <div style="font-size: 20px; font-weight: 700; color: var(--accent); font-family: 'DM Serif Display', serif;">{{ $avgK }}</div>
            <div style="font-size: 10px; color: var(--text-muted);">Rata K</div>
        </div>
        <div class="stat-card" style="padding: 12px; text-align: center;">
            <div style="font-size: 20px; font-weight: 700; color: #B87F63; font-family: 'DM Serif Display', serif;">{{ $avgTotal }}</div>
            <div style="font-size: 10px; color: var(--text-muted);">Total</div>
        </div>
    </div>
    @endif

    <div class="card-tartil">
        @forelse($nilais as $n)
        @php $na = $n->nilai_akhir; @endphp
        <div style="padding: 14px 16px; border-bottom: 1px solid var(--border);">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <div style="font-weight: 500; font-size: 14px;">{{ $n->jurnal->surat }} ({{ $n->jurnal->ayat }})</div>
                    <div style="font-size: 12px; color: var(--text-muted);">{{ $n->jurnal->tanggal->format('d/m/Y') }} | {{ $n->jurnal->kelas->nama }}</div>
                </div>
                <div style="text-align: right;">
                    <div style="font-size: 18px; font-weight: 700; color: var(--accent); font-family: 'DM Serif Display', serif;">{{ round($na) }}</div>
                    <span class="badge-subject" style="background: {{ $na >= 85 ? '#E9F0E9' : ($na >= 75 ? '#E9EEF0' : ($na >= 65 ? '#F0ECE9' : '#F0E9E9')) }}; color: {{ $na >= 85 ? '#5A7D5A' : ($na >= 75 ? '#5A7A8A' : ($na >= 65 ? '#8A7A6B' : '#A85A52')) }};">
                        {{ $n->predikat }}
                    </span>
                </div>
            </div>
            <div style="display: flex; gap: 16px; margin-top: 8px; font-size: 12px; color: var(--text-muted);">
                <span>B: {{ $n->nilai_b }}</span>
                <span>C: {{ $n->nilai_c }}</span>
                <span>K: {{ $n->nilai_k }}</span>
            </div>
            @if($n->catatan)
            <div style="margin-top: 6px; font-size: 12px; color: var(--text-secondary); font-style: italic;">"{{ $n->catatan }}"</div>
            @endif
        </div>
        @empty
        <div style="padding: 40px; text-align: center; color: var(--text-muted);">Belum ada data nilai untuk semester ini.</div>
        @endforelse
    </div>
    {{ $nilais->links() }}
</div>
@endsection
