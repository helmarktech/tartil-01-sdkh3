@extends('layouts.siswa')
@section('title', 'Riwayat Munaqosyah')

@section('content')
<div>
    <div class="page-header">
        <div>
            <h1 class="page-title-display">Riwayat Munaqosyah</h1>
            <p class="page-subtitle">Daftar ujian munaqosyah yang pernah diikuti</p>
        </div>
    </div>

    <div class="card-tartil table-responsive">
        <table class="table-tartil">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Ujian</th>
                    <th>Tingkat</th>
                    <th>Tanggal</th>
                    <th>Semester</th>
                    <th>Status</th>
                    <th>Nilai</th>
                    <th>Catatan</th>
                </tr>
            </thead>
            <tbody>
                @forelse($riwayat as $i => $r)
                <tr>
                    <td>{{ $riwayat->firstItem() + $i }}</td>
                    <td style="font-weight: 500;">{{ $r->munaqosyah->nama ?? '-' }}</td>
                    <td><span class="badge-subject">{{ ucfirst($r->munaqosyah->tingkat ?? '-') }}</span></td>
                    <td>{{ $r->munaqosyah->tanggal_ujian ? date('d/m/Y', strtotime($r->munaqosyah->tanggal_ujian)) : '-' }}</td>
                    <td>{{ $r->munaqosyah->semester->nama ?? '-' }}</td>
                    <td>
                        @if($r->status == 'terdaftar')
                            <span class="badge-warning">Terdaftar</span>
                        @elseif($r->status == 'lulus')
                            <span class="badge-success">Lulus</span>
                        @else
                            <span class="badge-error">Tidak Lulus</span>
                        @endif
                    </td>
                    <td>{{ $r->nilai ?? '-' }}</td>
                    <td>{{ $r->catatan ?? '-' }}</td>
                </tr>
                @empty
                <tr><td colspan="8" style="text-align: center; color: var(--text-muted);">Belum ada riwayat ujian munaqosyah.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
    {{ $riwayat->links() }}
</div>
@endsection
