@extends('layouts.admin')
@section('title', 'Rekap Nilai')

@section('content')
<div>
    {{-- Header --}}
    <div class="page-header" style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 12px;">
        <div>
            <h1 class="page-title-display">REKAP NILAI</h1>
            <p class="page-subtitle">{{ $kelasAktif ? $kelasAktif->nama . ' — ' . \Carbon\Carbon::createFromFormat('Ym', $bulan)->locale('id')->isoFormat('MMMM YYYY') : 'Pilih kelas dan bulan' }}</p>
        </div>
    </div>

    {{-- Filter --}}
    <div style="display: flex; gap: 12px; margin-bottom: 20px; flex-wrap: wrap;">
        <select name="kelas_id" class="form-input" onchange="changeKelas(this.value)" style="min-width: 200px; font-size: 14px;">
            @foreach($kelasList as $k)
            <option value="{{ $k->id }}" {{ $kelasId == $k->id ? 'selected' : '' }}>{{ $k->nama }}</option>
            @endforeach
        </select>
        <input type="month" class="form-input" value="{{ substr($bulan, 0, 4) . '-' . substr($bulan, 4, 2) }}"
            onchange="changeBulan(this.value)" style="min-width: 160px;">
        <a href="{{ route('guru.jurnal.rekap', ['kelas_id' => $kelasId, 'bulan' => $bulan, 'export' => 'excel']) }}" class="btn-tartil-outline" style="font-size: 13px; text-decoration: none;">
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 4px;"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            Export Excel
        </a>
    </div>

    @if($kelasAktif && count($tanggalList) > 0)
    {{-- Summary Cards --}}
    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; margin-bottom: 24px;">
        <div class="card-tartil" style="display: flex; align-items: center; gap: 16px; padding: 20px;">
            <div style="width: 44px; height: 44px; border-radius: 10px; background: #f5f0eb; display: flex; align-items: center; justify-content: center;">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#8B7355" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
            </div>
            <div>
                <div style="font-size: 12px; color: var(--text-muted);">SISWA</div>
                <div style="font-size: 28px; font-weight: 700; color: var(--text-primary);">{{ $siswaList->count() }}</div>
            </div>
        </div>
        <div class="card-tartil" style="display: flex; align-items: center; gap: 16px; padding: 20px;">
            <div style="width: 44px; height: 44px; border-radius: 10px; background: #f5f0eb; display: flex; align-items: center; justify-content: center;">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#8B7355" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
            </div>
            <div>
                <div style="font-size: 12px; color: var(--text-muted);">PERTEMUAN</div>
                <div style="font-size: 28px; font-weight: 700; color: var(--text-primary);">{{ count($tanggalList) }}</div>
            </div>
        </div>
        <div class="card-tartil" style="display: flex; align-items: center; gap: 16px; padding: 20px;">
            <div style="width: 44px; height: 44px; border-radius: 10px; background: #f5f0eb; display: flex; align-items: center; justify-content: center;">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#8B7355" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>
            </div>
            <div>
                <div style="font-size: 12px; color: var(--text-muted);">RATA-RATA</div>
                <div style="font-size: 28px; font-weight: 700; color: var(--text-primary);">{{ $rataRataKelas }}%</div>
            </div>
        </div>
    </div>

    {{-- Tabel Rekap --}}
    <div class="card-tartil" style="padding: 0; overflow: hidden;">
        <div class="table-responsive">
            <table class="table-tartil" id="rekapTable" style="font-size: 12px;">
                <thead>
                    <tr style="background: var(--bg-body);">
                        <th rowspan="2" style="width: 30px; text-align: center; vertical-align: middle;">NO</th>
                        <th rowspan="2" style="width: 50px; text-align: center; vertical-align: middle;">NIS</th>
                        <th rowspan="2" style="width: 60px; text-align: center; vertical-align: middle;">KELAS</th>
                        <th rowspan="2" style="min-width: 160px; vertical-align: middle;">NAMA SISWA</th>
                        <th colspan="{{ count($tanggalList) }}" style="text-align: center;">TANGGAL / PERTEMUAN</th>
                        <th colspan="3" style="text-align: center; min-width: 120px;">PROSENTASE KEBERHASILAN</th>
                    </tr>
                    <tr style="background: var(--bg-body);">
                        @foreach($tanggalList as $t)
                        <th style="text-align: center; min-width: 32px; font-size: 10px;">
                            <div>{{ $t['tanggal']->format('d') }}</div>
                            <div style="font-size: 9px; text-transform: uppercase;">{{ $t['tanggal']->format('M') }}</div>
                        </th>
                        @endforeach
                        <th style="text-align: center; font-size: 10px;">B+C</th>
                        <th style="text-align: center; font-size: 10px;">K</th>
                        <th style="text-align: center; font-size: 10px;">%</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($siswaList as $i => $s)
                    @php
                        $dataSiswa = $rekapData[$s->id] ?? [];
                        $countBaikCukup = $dataSiswa['summary']['b_c'] ?? 0;
                        $countKurang = $dataSiswa['summary']['k'] ?? 0;
                        $totalPertemuan = count($tanggalList);
                        $persen = $totalPertemuan > 0 ? round(($countBaikCukup / $totalPertemuan) * 100) : 0;
                    @endphp
                    <tr>
                        <td style="text-align: center;">{{ $i + 1 }}</td>
                        <td style="text-align: center; color: var(--text-muted);">{{ $s->nis ?? '-' }}</td>
                        <td style="text-align: center; color: var(--text-muted);">{{ $s->kelasReguler->nama ?? '-' }}</td>
                        <td style="font-weight: 600;">{{ $s->nama }}</td>
                        @foreach($tanggalList as $t)
                        @php
                            $nilai = $dataSiswa['nilai'][$t['tanggal_str']] ?? null;
                            $bgClass = '';
                            if ($nilai == 'B') $bgClass = 'style="background: #E9F0E9; color: #5A7D5A; font-weight: 600;"';
                            elseif ($nilai == 'C') $bgClass = 'style="background: #FFF8E1; color: #B8860B; font-weight: 600;"';
                            elseif ($nilai == 'K') $bgClass = 'style="background: #FBE9E7; color: #C62828; font-weight: 600;"';
                        @endphp
                        <td style="text-align: center;" {!! $bgClass !!}>{{ $nilai ?? '-' }}</td>
                        @endforeach
                        <td style="text-align: center; font-weight: 600;">{{ $countBaikCukup }}</td>
                        <td style="text-align: center; color: #C62828; font-weight: 600;">{{ $countKurang }}</td>
                        <td style="text-align: center; font-weight: 600;">{{ $persen }}%</td>
                    </tr>
                    @endforeach

                    {{-- Separator --}}
                    <tr><td colspan="{{ 7 + count($tanggalList) }}" style="height: 2px; background: var(--border); padding: 0;"></td></tr>

                    {{-- Baris Summary B+C --}}
                    <tr class="rekap-summary-row">
                        <td colspan="4" class="rekap-summary-label">B+C</td>
                        @foreach($tanggalList as $t)
                        <td class="rekap-summary-b">{{ $summaryPerTanggal[$t['tanggal_str']]['b_c'] ?? 0 }}</td>
                        @endforeach
                        <td colspan="3" class="rekap-summary-empty"></td>
                    </tr>

                    {{-- Baris Summary K --}}
                    <tr class="rekap-summary-row">
                        <td colspan="4" class="rekap-summary-label">K</td>
                        @foreach($tanggalList as $t)
                        <td class="rekap-summary-k">{{ $summaryPerTanggal[$t['tanggal_str']]['k'] ?? 0 }}</td>
                        @endforeach
                        <td colspan="3" class="rekap-summary-empty"></td>
                    </tr>

                    {{-- Baris Prosentase Hasil (%) --}}
                    <tr class="rekap-pct-row">
                        <td colspan="4" class="rekap-pct-label">PROSENTASE HASIL (%)</td>
                        @foreach($tanggalList as $t)
                        @php
                            $totalSiswa = $siswaList->count();
                            $bc = $summaryPerTanggal[$t['tanggal_str']]['b_c'] ?? 0;
                            $pct = $totalSiswa > 0 ? round(($bc / $totalSiswa) * 100) : 0;
                        @endphp
                        <td class="rekap-pct-value">{{ $pct }}%</td>
                        @endforeach
                        <td colspan="3" class="rekap-summary-empty"></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    @elseif($kelasAktif)
    <div class="card-tartil" style="text-align: center; padding: 60px;">
        <div style="color: var(--text-muted); font-size: 14px;">Belum ada data penilaian untuk kelas dan bulan ini.</div>
    </div>
    @else
    <div class="card-tartil" style="text-align: center; padding: 60px;">
        <div style="color: var(--text-muted); font-size: 14px;">Pilih kelas untuk melihat rekap.</div>
    </div>
    @endif
</div>
@endsection

@push('styles')
<style>
/* Summary rows styling */
.rekap-summary-row {
    background: #f5f0eb !important;
    font-weight: 700;
}
.rekap-summary-row td {
    border-top: 1px solid #e0d8cf;
    border-bottom: 1px solid #e0d8cf;
    padding: 8px 6px;
}
.rekap-summary-label {
    text-align: right;
    padding-right: 14px;
    font-size: 13px;
    color: #5a4a3a;
    background: #f5f0eb;
}
.rekap-summary-b {
    text-align: center;
    font-weight: 700;
    color: #5a4a3a;
    font-size: 12px;
    background: #f5f0eb;
}
.rekap-summary-k {
    text-align: center;
    font-weight: 700;
    color: #C62828;
    font-size: 12px;
    background: #f5f0eb;
}
.rekap-summary-empty {
    background: #f5f0eb;
}

/* Prosentase hasil row */
.rekap-pct-row {
    background: #ebe5db !important;
    font-weight: 700;
}
.rekap-pct-row td {
    border-top: 2px solid #c4b8a8;
    padding: 10px 6px;
}
.rekap-pct-label {
    text-align: right;
    padding-right: 14px;
    font-size: 11px;
    color: #5a4a3a;
    text-transform: uppercase;
    letter-spacing: 0.3px;
    background: #ebe5db;
}
.rekap-pct-value {
    text-align: center;
    font-weight: 700;
    color: #5a4a3a;
    font-size: 12px;
    background: #ebe5db;
}

/* Siswa row styling */
#rekapTable tbody tr:not(.rekap-summary-row):not(.rekap-pct-row):hover {
    background: #faf9f7;
}
</style>
@endpush

@push('scripts')
<script>
function changeKelas(id) {
    const url = new URL(window.location.href);
    url.searchParams.set('kelas_id', id);
    window.location.href = url.toString();
}
function changeBulan(val) {
    const bulan = val.replace('-', '');
    const url = new URL(window.location.href);
    url.searchParams.set('bulan', bulan);
    window.location.href = url.toString();
}
function exportExcel() {
    const table = document.getElementById('rekapTable');
    if (!table) { alert('Tidak ada data untuk di-export.'); return; }

    let csv = '\uFEFF'; // BOM for UTF-8
    const rows = table.querySelectorAll('tr');
    rows.forEach(row => {
        const cols = row.querySelectorAll('th, td');
        const rowData = [];
        cols.forEach(col => {
            let text = col.textContent.trim().replace(/"/g, '""');
            rowData.push('"' + text + '"');
        });
        csv += rowData.join(',') + '\n';
    });

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'rekap_nilai_{{ $kelasAktif?->nama ?? "kelas" }}_{{ $bulan }}.csv';
    link.click();
}
</script>
@endpush
