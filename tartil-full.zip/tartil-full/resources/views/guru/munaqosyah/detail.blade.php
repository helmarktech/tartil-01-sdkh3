@extends('layouts.admin')
@section('title', 'Detail Munaqosyah')

@section('content')
<div>
    <div class="page-header" style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 12px;">
        <div>
            <h1 class="page-title-display">{{ $munaqosyah->nama }}</h1>
            <p class="page-subtitle">{{ ucfirst($munaqosyah->tingkat) }} - {{ $munaqosyah->tanggal_ujian ? date('d/m/Y', strtotime($munaqosyah->tanggal_ujian)) : '-' }}</p>
        </div>
        <a href="{{ route('guru.munaqosyah.index') }}" class="btn-tartil-outline" style="text-decoration: none;">Kembali</a>
    </div>

    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 12px; margin-bottom: 20px;">
        <div class="card-tartil" style="text-align: center;">
            <div style="font-size: 24px; font-weight: 600; color: var(--accent);">{{ $munaqosyah->pendaftarans->count() }}</div>
            <div style="font-size: 12px; color: var(--text-muted);">Total Pendaftar</div>
        </div>
        <div class="card-tartil" style="text-align: center;">
            <div style="font-size: 24px; font-weight: 600; color: #5A7D5A;">{{ $munaqosyah->pendaftarans->where('status', 'lulus')->count() }}</div>
            <div style="font-size: 12px; color: var(--text-muted);">Lulus</div>
        </div>
        <div class="card-tartil" style="text-align: center;">
            <div style="font-size: 24px; font-weight: 600; color: #A85A52;">{{ $munaqosyah->pendaftarans->where('status', 'tidak_lulus')->count() }}</div>
            <div style="font-size: 12px; color: var(--text-muted);">Tidak Lulus</div>
        </div>
        <div class="card-tartil" style="text-align: center;">
            <div style="font-size: 24px; font-weight: 600; color: var(--text-secondary);">{{ $munaqosyah->pendaftarans->where('status', 'terdaftar')->count() }}</div>
            <div style="font-size: 12px; color: var(--text-muted);">Menunggu</div>
        </div>
    </div>

    {{-- Guru: Daftarkan Siswa (hanya dari kelas sendiri, checkbox massal) --}}
    @if($siswas->count() > 0)
    <div class="card-tartil" style="margin-bottom: 20px; padding: 24px;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; flex-wrap: wrap; gap: 8px;">
            <h3 style="font-size: 16px; margin: 0; color: var(--text-primary); font-weight: 600;">Daftarkan Siswa ({{ $siswas->count() }} dari kelas Anda)</h3>
            <label style="display: flex; align-items: center; gap: 6px; cursor: pointer; font-size: 12px; color: var(--text-muted);">
                <input type="checkbox" id="check-all" onclick="toggleCheckAll()">
                <span>Pilih Semua</span>
            </label>
        </div>

        <form method="POST" action="{{ route('guru.munaqosyah.daftarkan', $munaqosyah->id) }}">
            @csrf
            <div class="table-responsive" style="margin-bottom: 16px;">
                <table class="table-tartil" style="font-size: 13px; min-width: 500px;">
                    <thead>
                        <tr>
                            <th style="width: 40px;"></th>
                            <th>No</th>
                            <th>NIS</th>
                            <th>Nama</th>
                            <th>Kelas Reguler</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($siswas as $i => $s)
                        <tr>
                            <td style="text-align: center;">
                                <input type="checkbox" name="siswa_ids[]" class="siswa-check" value="{{ $s->id }}">
                            </td>
                            <td>{{ $i + 1 }}</td>
                            <td>{{ $s->nis }}</td>
                            <td style="font-weight: 500;">{{ $s->nama }}</td>
                            <td>{{ $s->kelasReguler->nama ?? '-' }}</td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            <button type="submit" class="btn-tartil" onclick="return validateDaftar()">Daftarkan Siswa Terpilih</button>
        </form>
    </div>
    @else
    <div class="card-tartil" style="padding: 24px; text-align: center; margin-bottom: 20px;">
        <p style="color: var(--text-muted); font-size: 14px;">Tidak ada siswa yang tersedia dari kelas Anda, atau semua siswa sudah terdaftar.</p>
    </div>
    @endif

    {{-- Input Nilai --}}
    @if($munaqosyah->pendaftarans->count() > 0)
    <div class="card-tartil" style="margin-bottom: 20px; padding: 24px;">
        <h3 style="font-size: 16px; margin-bottom: 16px; color: var(--text-primary); font-weight: 600;">Input Nilai & Status</h3>
        <form method="POST" action="{{ route('guru.munaqosyah.nilai', $munaqosyah->id) }}">
            @csrf
            <div class="table-responsive">
                <table class="table-tartil" style="font-size: 13px;">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Status</th>
                            <th>Nilai</th>
                            <th>Catatan</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($munaqosyah->pendaftarans as $i => $p)
                        <tr>
                            <td>{{ $i + 1 }}</td>
                            <td style="font-weight: 500;">{{ $p->siswa->nama ?? '-' }}</td>
                            <td>
                                <input type="hidden" name="nilai[{{ $i }}][pendaftaran_id]" value="{{ $p->id }}">
                                <select name="nilai[{{ $i }}][status]" class="form-input" style="min-width: 140px;">
                                    <option value="terdaftar" {{ $p->status == 'terdaftar' ? 'selected' : '' }}>Terdaftar</option>
                                    <option value="lulus" {{ $p->status == 'lulus' ? 'selected' : '' }}>Lulus</option>
                                    <option value="tidak_lulus" {{ $p->status == 'tidak_lulus' ? 'selected' : '' }}>Tidak Lulus</option>
                                </select>
                            </td>
                            <td><input type="number" name="nilai[{{ $i }}][nilai]" value="{{ $p->nilai }}" class="form-input" min="0" max="100" style="max-width: 80px;"></td>
                            <td><input type="text" name="nilai[{{ $i }}][catatan]" value="{{ $p->catatan }}" class="form-input" placeholder="Catatan..."></td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            <div style="display: flex; gap: 8px; margin-top: 16px; flex-wrap: wrap;">
                <button type="submit" class="btn-tartil">Simpan Nilai</button>
                <form method="POST" action="{{ route('guru.munaqosyah.lulussemua', $munaqosyah->id) }}" style="display:inline;">
                    @csrf
                    <button type="submit" class="btn-tartil-success" onclick="return confirm('Luluskan semua siswa?')">Lulus Semua</button>
                </form>
                <form method="POST" action="{{ route('guru.munaqosyah.tidaklulussemua', $munaqosyah->id) }}" style="display:inline;">
                    @csrf
                    <button type="submit" class="btn-tartil-danger" onclick="return confirm('Tidak luluskan semua siswa?')">Tidak Lulus Semua</button>
                </form>
            </div>
        </form>
    </div>
    @endif

    {{-- Daftar Pendaftar --}}
    <h3 style="font-size: 16px; margin: 24px 0 12px; color: var(--text-primary); font-weight: 600;">Daftar Pendaftar</h3>
    <div class="card-tartil table-responsive">
        <table class="table-tartil" style="font-size: 13px;">
            <thead>
                <tr>
                    <th>No</th>
                    <th>NIS</th>
                    <th>Nama</th>
                    <th>Status</th>
                    <th>Nilai</th>
                    <th>Catatan</th>
                </tr>
            </thead>
            <tbody>
                @forelse($munaqosyah->pendaftarans as $i => $p)
                <tr>
                    <td>{{ $i + 1 }}</td>
                    <td>{{ $p->siswa->nis ?? '-' }}</td>
                    <td style="font-weight: 500;">{{ $p->siswa->nama ?? '-' }}</td>
                    <td>
                        @if($p->status == 'terdaftar')
                            <span class="badge-warning">Terdaftar</span>
                        @elseif($p->status == 'lulus')
                            <span class="badge-success">Lulus</span>
                        @else
                            <span class="badge-error">Tidak Lulus</span>
                        @endif
                    </td>
                    <td>{{ $p->nilai ?? '-' }}</td>
                    <td>{{ $p->catatan ?? '-' }}</td>
                </tr>
                @empty
                <tr><td colspan="6" style="text-align: center; color: var(--text-muted);">Belum ada pendaftar.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection

@push('scripts')
<script>
function toggleCheckAll() {
    const checkAll = document.getElementById('check-all');
    const checks = document.querySelectorAll('.siswa-check');
    checks.forEach(c => c.checked = checkAll.checked);
}
function validateDaftar() {
    const checks = document.querySelectorAll('.siswa-check:checked');
    if (checks.length === 0) {
        alert('Pilih minimal 1 siswa yang akan didaftarkan.');
        return false;
    }
    return confirm('Daftarkan ' + checks.length + ' siswa terpilih ke ujian ini?');
}
</script>
@endpush
