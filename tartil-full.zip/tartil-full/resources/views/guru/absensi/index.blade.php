@extends('layouts.admin')
@section('title', 'Absensi')

@section('content')
<div>
    <div class="page-header">
        <h1 class="page-title-display">Absensi</h1>
        <p class="page-subtitle">Riwayat kehadiran siswa</p>
    </div>

    <div class="card-tartil" style="padding: 16px 20px; margin-bottom: 20px;">
        <form method="GET" action="{{ route('guru.absensi.index') }}" style="display: flex; gap: 12px; flex-wrap: wrap; margin: 0;">
            <select name="kelas" onchange="this.form.submit()" style="padding: 10px 12px; border-radius: 10px; border: 1px solid var(--border); font-size: 14px; min-width: 160px;">
                <option value="">Semua Kelas</option>
                @foreach($kelasList as $k)
                <option value="{{ $k->id }}" {{ request('kelas') == $k->id ? 'selected' : '' }}>{{ $k->nama }}</option>
                @endforeach
            </select>
            <input type="date" name="dari" value="{{ request('dari') }}" onchange="this.form.submit()" style="padding: 10px 12px; border-radius: 10px; border: 1px solid var(--border); font-size: 14px;">
            <input type="date" name="sampai" value="{{ request('sampai') }}" onchange="this.form.submit()" style="padding: 10px 12px; border-radius: 10px; border: 1px solid var(--border); font-size: 14px;">
        </form>
    </div>

    <div class="card-tartil table-responsive">
        <table class="table-tartil">
            <thead>
                <tr>
                    <th>Tanggal</th>
                    <th>Siswa</th>
                    <th>Kelas</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                @forelse($absensis as $a)
                <tr>
                    <td>{{ $a->tanggal->format('d/m/Y') }}</td>
                    <td style="font-weight: 500;">{{ $a->siswa->nama }}</td>
                    <td>{{ $a->kelas->nama }}</td>
                    <td>
                        <span class="badge-subject" style="background: {{ $a->status == 'Hadir' ? '#E9F0E9' : ($a->status == 'Sakit' ? '#F0ECE9' : ($a->status == 'Izin' ? '#E9EEF0' : '#F0E9E9')) }}; color: {{ $a->status == 'Hadir' ? '#5A7D5A' : ($a->status == 'Sakit' ? '#C4953A' : ($a->status == 'Izin' ? '#5A7A8A' : '#A85A52')) }};">
                            {{ $a->status }}
                        </span>
                    </td>
                </tr>
                @empty
                <tr><td colspan="4" style="text-align: center; color: var(--text-muted); padding: 40px;">Belum ada data absensi.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
    {{ $absensis->links() }}
</div>
@endsection
