@extends('layouts.auth')
@section('title', 'Login Siswa')

@section('content')
<div class="login-container">
    <div class="login-card">
        <div style="text-align: center; margin-bottom: 24px;">
            <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="color: var(--accent);"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>
            <h1 style="font-family: 'DM Serif Display', serif; font-size: 24px; margin: 8px 0 4px;">Tartil</h1>
            <p style="color: var(--text-muted); font-size: 13px;">Login Siswa</p>
        </div>

        @if(session('error'))
        <div class="alert-error" style="margin-bottom: 16px;">
            {{ session('error') }}
        </div>
        @endif

        <form method="POST" action="{{ route('siswa.login.post') }}">
            @csrf
            <div class="form-group">
                <label class="form-label">NIS (Nomor Induk Siswa)</label>
                <input type="text" name="nis" class="form-input" value="{{ old('nis') }}" required autofocus placeholder="Contoh: 2024001">
            </div>

            <div class="form-group">
                <label class="form-label">Nomor HP</label>
                <input type="text" name="no_hp" class="form-input" required placeholder="08xxxxxxxxxx">
            </div>

            <div class="form-group" style="display: flex; align-items: center; gap: 8px;">
                <input type="checkbox" name="remember" id="remember" style="accent-color: var(--accent);">
                <label for="remember" style="font-size: 13px; color: var(--text-secondary); cursor: pointer;">Ingat saya</label>
            </div>

            <button type="submit" class="btn-tartil" style="width: 100%; justify-content: center;">
                Masuk
            </button>
        </form>

        <div style="margin-top: 20px; text-align: center;">
            <a href="{{ route('login') }}" class="link-tartil">Login sebagai Admin/Guru</a>
        </div>
    </div>
</div>
@endsection
