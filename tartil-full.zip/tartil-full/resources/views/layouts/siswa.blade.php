<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title') - Tartil</title>
    <link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <link href="{{ asset('css/tartil.css') }}" rel="stylesheet">
    <style>
        .siswa-nav { display: flex; gap: 4px; overflow-x: auto; padding: 8px 0; margin-bottom: 16px; -webkit-overflow-scrolling: touch; }
        .siswa-nav a { white-space: nowrap; padding: 8px 16px; border-radius: 9999px; font-size: 13px; font-weight: 500; text-decoration: none; color: var(--text-secondary); background: var(--bg-card); border: 1px solid var(--border); }
        .siswa-nav a.active { background: var(--accent); color: white; border-color: var(--accent); }
        .form-label { display: block; font-size: 12px; font-weight: 500; color: var(--text-secondary); margin-bottom: 4px; }
        .form-input { width: 100%; padding: 10px 12px; border-radius: 10px; border: 1px solid var(--border); font-size: 14px; font-family: 'Inter', sans-serif; background: var(--bg-card); }
        .form-input:focus { outline: none; border-color: var(--accent); box-shadow: 0 0 0 3px rgba(107,94,81,0.1); }
    </style>
    @stack('styles')
</head>
<body>
    <div class="tartil-wrapper">
        <div class="tartil-main" style="margin-left: 0;">
            <header class="tartil-topbar">
                <div style="display: flex; align-items: center; gap: 10px;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="color: var(--accent)"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>
                    <span style="font-family: 'DM Serif Display', serif; font-size: 16px;">Tartil</span>
                    <span style="font-size: 12px; color: var(--text-muted);">| Siswa</span>
                </div>
                <form method="POST" action="{{ route('siswa.logout') }}" style="margin: 0;">
                    @csrf
                    <button type="submit" style="background: none; border: none; color: var(--text-muted); font-size: 12px; cursor: pointer;">Keluar</button>
                </form>
            </header>

            <main class="tartil-content">
                <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 16px;">
                    <div class="student-avatar" style="width: 40px; height: 40px; font-size: 14px;">{{ auth('siswa')->user()->initials }}</div>
                    <div>
                        <div style="font-weight: 600; font-size: 15px;">{{ auth('siswa')->user()->nama }}</div>
                        <div style="font-size: 11px; color: var(--text-muted);">NIS: {{ auth('siswa')->user()->nis }}</div>
                    </div>
                </div>

                <nav class="siswa-nav">
                    <a href="{{ route('siswa.dashboard') }}" class="{{ request()->routeIs('siswa.dashboard') ? 'active' : '' }}">Dashboard</a>
                    <a href="{{ route('siswa.nilai') }}" class="{{ request()->routeIs('siswa.nilai') ? 'active' : '' }}">Nilai</a>
                    <a href="{{ route('siswa.absensi') }}" class="{{ request()->routeIs('siswa.absensi') ? 'active' : '' }}">Absensi</a>
                    <a href="{{ route('siswa.perpindahan') }}" class="{{ request()->routeIs('siswa.perpindahan') ? 'active' : '' }}">Riwayat Kelas</a>
                </nav>

                @if(session('success'))
                <div class="alert-tartil alert-success" style="margin-bottom: 16px;">{{ session('success') }}</div>
                @endif
                @if(session('error'))
                <div class="alert-tartil alert-error" style="margin-bottom: 16px;">{{ session('error') }}</div>
                @endif

                @yield('content')
            </main>
        </div>
    </div>
    @stack('scripts')
</body>
</html>
