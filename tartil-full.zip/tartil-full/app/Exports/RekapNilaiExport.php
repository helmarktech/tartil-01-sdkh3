<?php

namespace App\Exports;

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class RekapNilaiExport
{
    protected $siswaList;
    protected $tanggalList;
    protected $rekapData;
    protected $summaryPerTanggal;
    protected $kelasNama;
    protected $bulanNama;

    public function __construct($siswaList, $tanggalList, $rekapData, $summaryPerTanggal, $kelasNama, $bulanNama)
    {
        $this->siswaList = $siswaList;
        $this->tanggalList = $tanggalList;
        $this->rekapData = $rekapData;
        $this->summaryPerTanggal = $summaryPerTanggal;
        $this->kelasNama = $kelasNama;
        $this->bulanNama = $bulanNama;
    }

    public function export(): Spreadsheet
    {
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setTitle('Rekap Nilai');

        // Colors
        $colorHeader = '8B7355';
        $colorHeaderBg = 'F5F0EB';
        $colorSummaryBg = 'EBE5DB';
        $colorBorder = 'C4B8A8';
        $colorGreen = 'E9F0E9';
        $colorYellow = 'FFF8E1';
        $colorRed = 'FBE9E7';
        $colorB = '5A7D5A';
        $colorC = 'B8860B';
        $colorK = 'C62828';

        // ===== TITLE =====
        $sheet->setCellValue('A1', 'REKAP NILAI');
        $sheet->mergeCells('A1:C1');
        $sheet->getStyle('A1')->getFont()->setBold(true)->setSize(18)->setColor(new \PhpOffice\PhpSpreadsheet\Style\Color($colorHeader));
        $sheet->getStyle('A1')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_LEFT);

        $sheet->setCellValue('A2', $this->kelasNama . ' — ' . $this->bulanNama);
        $sheet->mergeCells('A2:C2');
        $sheet->getStyle('A2')->getFont()->setSize(11)->setColor(new \PhpOffice\PhpSpreadsheet\Style\Color('8A8A8A'));

        // ===== SUMMARY CARDS ROW 4-6 =====
        $sheet->setCellValue('A4', 'SISWA');
        $sheet->setCellValue('A5', $this->siswaList->count());
        $sheet->setCellValue('C4', 'PERTEMUAN');
        $sheet->setCellValue('C5', count($this->tanggalList));
        $sheet->setCellValue('E4', 'RATA-RATA');
        $sheet->setCellValue('E5', $this->hitungRataRataKelas() . '%');

        foreach (['A4', 'C4', 'E4'] as $cell) {
            $sheet->getStyle($cell)->getFont()->setSize(10)->setColor(new \PhpOffice\PhpSpreadsheet\Style\Color('8A8A8A'));
        }
        foreach (['A5', 'C5', 'E5'] as $cell) {
            $sheet->getStyle($cell)->getFont()->setBold(true)->setSize(22);
        }

        // ===== HEADERS =====
        $headerRow = 7;
        $col = 1;

        $sheet->setCellValueByColumnAndRow($col++, $headerRow, 'NO');
        $sheet->setCellValueByColumnAndRow($col++, $headerRow, 'NIS');
        $sheet->setCellValueByColumnAndRow($col++, $headerRow, 'KELAS');
        $sheet->setCellValueByColumnAndRow($col++, $headerRow, 'NAMA SISWA');

        $colTanggalStart = $col;
        foreach ($this->tanggalList as $t) {
            $sheet->setCellValueByColumnAndRow($col, $headerRow, $t['tanggal']->format('d'));
            $sheet->setCellValueByColumnAndRow($col, $headerRow + 1, strtoupper($t['tanggal']->format('M')));
            $col++;
        }

        $sheet->setCellValueByColumnAndRow($col++, $headerRow, 'B+C');
        $sheet->setCellValueByColumnAndRow($col++, $headerRow, 'K');
        $sheet->setCellValueByColumnAndRow($col, $headerRow, '%');

        // Style headers
        $lastCol = $col;
        $sheet->mergeCellsByColumnAndRow(1, $headerRow, 1, $headerRow + 1);
        $sheet->mergeCellsByColumnAndRow(2, $headerRow, 2, $headerRow + 1);
        $sheet->mergeCellsByColumnAndRow(3, $headerRow, 3, $headerRow + 1);
        $sheet->mergeCellsByColumnAndRow(4, $headerRow, 4, $headerRow + 1);

        $headerRange = $sheet->getCellByColumnAndRow(1, $headerRow)->getCoordinate() . ':' . $sheet->getCellByColumnAndRow($lastCol, $headerRow + 1)->getCoordinate();
        $sheet->getStyle($headerRange)->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB($colorHeaderBg);
        $sheet->getStyle($headerRange)->getFont()->setBold(true)->setSize(10)->setColor(new \PhpOffice\PhpSpreadsheet\Style\Color($colorHeader));
        $sheet->getStyle($headerRange)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER)->setVertical(Alignment::VERTICAL_CENTER);
        $sheet->getStyle($headerRange)->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN)->getColor()->setRGB($colorBorder);

        // ===== DATA SISWA =====
        $row = $headerRow + 2;
        foreach ($this->siswaList as $i => $s) {
            $dataSiswa = $this->rekapData[$s->id] ?? [];
            $countBaikCukup = $dataSiswa['summary']['b_c'] ?? 0;
            $countKurang = $dataSiswa['summary']['k'] ?? 0;
            $totalPertemuan = count($this->tanggalList);
            $persen = $totalPertemuan > 0 ? round(($countBaikCukup / $totalPertemuan) * 100) : 0;

            $col = 1;
            $sheet->setCellValueByColumnAndRow($col++, $row, $i + 1);
            $sheet->setCellValueByColumnAndRow($col++, $row, $s->nis ?? '-');
            $sheet->setCellValueByColumnAndRow($col++, $row, $s->kelasReguler->nama ?? '-');
            $sheet->setCellValueByColumnAndRow($col++, $row, $s->nama);

            foreach ($this->tanggalList as $t) {
                $nilai = $dataSiswa['nilai'][$t['tanggal_str']] ?? null;
                $sheet->setCellValueByColumnAndRow($col, $row, $nilai ?? '-');
                $sheet->getStyleByColumnAndRow($col, $row)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);

                // Color cells based on nilai
                if ($nilai == 'B') {
                    $sheet->getStyleByColumnAndRow($col, $row)->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB($colorGreen);
                    $sheet->getStyleByColumnAndRow($col, $row)->getFont()->setColor(new \PhpOffice\PhpSpreadsheet\Style\Color($colorB))->setBold(true);
                } elseif ($nilai == 'C') {
                    $sheet->getStyleByColumnAndRow($col, $row)->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB($colorYellow);
                    $sheet->getStyleByColumnAndRow($col, $row)->getFont()->setColor(new \PhpOffice\PhpSpreadsheet\Style\Color($colorC))->setBold(true);
                } elseif ($nilai == 'K') {
                    $sheet->getStyleByColumnAndRow($col, $row)->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB($colorRed);
                    $sheet->getStyleByColumnAndRow($col, $row)->getFont()->setColor(new \PhpOffice\PhpSpreadsheet\Style\Color($colorK))->setBold(true);
                }
                $col++;
            }

            $sheet->setCellValueByColumnAndRow($col++, $row, $countBaikCukup);
            $sheet->getStyleByColumnAndRow($col - 1, $row)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);

            $sheet->setCellValueByColumnAndRow($col++, $row, $countKurang);
            $sheet->getStyleByColumnAndRow($col - 1, $row)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
            $sheet->getStyleByColumnAndRow($col - 1, $row)->getFont()->setColor(new \PhpOffice\PhpSpreadsheet\Style\Color($colorK));

            $sheet->setCellValueByColumnAndRow($col, $row, $persen . '%');
            $sheet->getStyleByColumnAndRow($col, $row)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
            $sheet->getStyleByColumnAndRow($col, $row)->getFont()->setBold(true);

            // Borders for data row
            $dataRange = $sheet->getCellByColumnAndRow(1, $row)->getCoordinate() . ':' . $sheet->getCellByColumnAndRow($col, $row)->getCoordinate();
            $sheet->getStyle($dataRange)->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN)->getColor()->setRGB($colorBorder);

            $row++;
        }

        // ===== SUMMARY ROWS =====
        // B+C row
        $col = 1;
        $sheet->setCellValueByColumnAndRow($col, $row, '');
        $sheet->setCellValueByColumnAndRow($col + 3, $row, 'B+C');
        $sheet->getStyleByColumnAndRow($col + 3, $row)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_RIGHT);
        $sheet->getStyleByColumnAndRow($col + 3, $row)->getFont()->setBold(true);
        $col = 5;
        foreach ($this->tanggalList as $t) {
            $val = $this->summaryPerTanggal[$t['tanggal_str']]['b_c'] ?? 0;
            $sheet->setCellValueByColumnAndRow($col, $row, $val);
            $sheet->getStyleByColumnAndRow($col, $row)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
            $col++;
        }
        $sumRange = $sheet->getCellByColumnAndRow(1, $row)->getCoordinate() . ':' . $sheet->getCellByColumnAndRow($col + 2, $row)->getCoordinate();
        $sheet->getStyle($sumRange)->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB($colorSummaryBg);
        $sheet->getStyle($sumRange)->getFont()->setBold(true);
        $sheet->getStyle($sumRange)->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN)->getColor()->setRGB($colorBorder);
        $row++;

        // K row
        $col = 1;
        $sheet->setCellValueByColumnAndRow($col + 3, $row, 'K');
        $sheet->getStyleByColumnAndRow($col + 3, $row)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_RIGHT);
        $sheet->getStyleByColumnAndRow($col + 3, $row)->getFont()->setBold(true)->setColor(new \PhpOffice\PhpSpreadsheet\Style\Color($colorK));
        $col = 5;
        foreach ($this->tanggalList as $t) {
            $val = $this->summaryPerTanggal[$t['tanggal_str']]['k'] ?? 0;
            $sheet->setCellValueByColumnAndRow($col, $row, $val);
            $sheet->getStyleByColumnAndRow($col, $row)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
            $col++;
        }
        $sumRange = $sheet->getCellByColumnAndRow(1, $row)->getCoordinate() . ':' . $sheet->getCellByColumnAndRow($col + 2, $row)->getCoordinate();
        $sheet->getStyle($sumRange)->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB($colorSummaryBg);
        $sheet->getStyle($sumRange)->getFont()->setBold(true);
        $sheet->getStyle($sumRange)->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN)->getColor()->setRGB($colorBorder);
        $row++;

        // PROSENTASE HASIL (%) row
        $col = 1;
        $sheet->setCellValueByColumnAndRow($col + 3, $row, 'PROSENTASE HASIL (%)');
        $sheet->getStyleByColumnAndRow($col + 3, $row)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_RIGHT);
        $sheet->getStyleByColumnAndRow($col + 3, $row)->getFont()->setBold(true)->setSize(9);
        $col = 5;
        $totalSiswa = $this->siswaList->count();
        foreach ($this->tanggalList as $t) {
            $bc = $this->summaryPerTanggal[$t['tanggal_str']]['b_c'] ?? 0;
            $pct = $totalSiswa > 0 ? round(($bc / $totalSiswa) * 100) : 0;
            $sheet->setCellValueByColumnAndRow($col, $row, $pct . '%');
            $sheet->getStyleByColumnAndRow($col, $row)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
            $col++;
        }
        $pctRange = $sheet->getCellByColumnAndRow(1, $row)->getCoordinate() . ':' . $sheet->getCellByColumnAndRow($col + 2, $row)->getCoordinate();
        $sheet->getStyle($pctRange)->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB('D9D0C5');
        $sheet->getStyle($pctRange)->getFont()->setBold(true);
        $sheet->getStyle($pctRange)->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN)->getColor()->setRGB($colorBorder);
        $sheet->getStyle($pctRange)->getBorders()->getTop()->setBorderStyle(Border::BORDER_MEDIUM);

        // ===== COLUMN WIDTHS =====
        $sheet->getColumnDimension('A')->setWidth(5);
        $sheet->getColumnDimension('B')->setWidth(10);
        $sheet->getColumnDimension('C')->setWidth(10);
        $sheet->getColumnDimension('D')->setWidth(25);
        $col = 5;
        foreach ($this->tanggalList as $t) {
            $sheet->getColumnDimensionByColumn($col)->setWidth(6);
            $col++;
        }
        $sheet->getColumnDimensionByColumn($col)->setWidth(7);
        $sheet->getColumnDimensionByColumn($col + 1)->setWidth(7);
        $sheet->getColumnDimensionByColumn($col + 2)->setWidth(8);

        // Freeze panes
        $sheet->freezePane('E9');

        return $spreadsheet;
    }

    private function hitungRataRataKelas(): int
    {
        $totalPersen = 0;
        $siswaCount = $this->siswaList->count();
        $tglCount = count($this->tanggalList);
        if ($siswaCount === 0 || $tglCount === 0) return 0;

        foreach ($this->rekapData as $data) {
            $totalPersen += round(($data['summary']['b_c'] / $tglCount) * 100);
        }
        return round($totalPersen / $siswaCount);
    }
}
