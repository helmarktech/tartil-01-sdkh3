<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Cache;
use App\Models\JurnalHarian;
use App\Models\JurnalKelas;
use App\Models\RekapJurnalBulanan;
use App\Models\Kelas;
use App\Models\Siswa;
use App\Models\Semester;
use App\Models\Surat;

class JurnalController extends Controller
{
    // ==================== GURU: HALAMAN JURNAL + ABSENSI ====================
    public function index(Request $request)
    {
        $guru = auth()->guard('web')->user()?->guru ?? null;
        $semesterAktif = Semester::aktif()->first();
        if (!$semesterAktif) {
            return view('guru.jurnal.index', ['noSemester' => true]);
        }

        // Guru hanya lihat kelas yang dia ajar
        $kelasQuery = Kelas::where('status', 'aktif');
        if ($guru) {
            $kelasQuery->where('guru_id', $guru->id);
        }
        $kelasList = $kelasQuery->orderBy('nama')->get();

        $kelasId = $request->get('kelas_id', $kelasList->first()?->id);
        $tanggal = $request->get('tanggal', now()->format('Y-m-d'));

        $kelasAktif = $kelasId ? $kelasList->firstWhere('id', $kelasId) : null;
        $siswaList = collect();
        $jurnalKelas = null;
        $penilaianMap = collect();

        if ($kelasAktif) {
            // Siswa aktif di kelas ini
            $siswaList = Siswa::where('status', 'aktif')
                ->where('kelas_tartil_id', $kelasId)
                ->with('kelasReguler')
                ->orderBy('nama')
                ->get();

            // Jurnal kelas (info umum) yang sudah diisi untuk tanggal ini
            $jurnalKelas = JurnalKelas::where('kelas_id', $kelasId)
                ->where('tanggal', $tanggal)
                ->first();

            // Penilaian per siswa yang sudah diisi untuk tanggal ini
            $penilaianExisting = JurnalHarian::where('kelas_id', $kelasId)
                ->where('tanggal', $tanggal)
                ->get()
                ->keyBy('siswa_id');
            $penilaianMap = $penilaianExisting;
        }

        $surats = Surat::orderBy('urutan')->get(['id', 'nama', 'jumlah_ayat']);

        return view('guru.jurnal.index', compact(
            'kelasList', 'kelasAktif', 'kelasId', 'tanggal',
            'siswaList', 'jurnalKelas', 'penilaianMap', 'surats', 'semesterAktif'
        ));
    }

    // ==================== BATCH STORE: JURNAL KELAS + ABSENSI SISWA ====================
    public function batchStore(Request $request)
    {
        $validated = $request->validate([
            'tanggal' => 'required|date',
            'kelas_id' => 'required|exists:kelas,id',
            'pertemuan_ke' => 'nullable|integer|min:1',
            'halaman_juz' => 'nullable|string|max:50',
            'surat_id' => 'nullable|exists:surats,id',
            'ayat' => 'nullable|string|max:50',
            'materi_pembelajaran' => 'nullable|string|max:255',
            'topik' => 'nullable|string|max:255',
            'rencana' => 'nullable|string|max:255',
            'catatan_kelas' => 'nullable|string',
            'entries' => 'required|array|min:1',
            'entries.*.siswa_id' => 'required|exists:siswas,id',
            'entries.*.penilaian' => 'nullable|in:B,C,K',
            'entries.*.catatan' => 'nullable|string|max:255',
        ], [
            'entries.required' => 'Tidak ada data penilaian siswa.',
        ]);

        $semesterAktif = Semester::aktif()->first();
        if (!$semesterAktif) {
            return response()->json(['error' => 'Tidak ada semester aktif.'], 422);
        }

        $guru = auth()->guard('web')->user()?->guru ?? null;
        $guruId = $guru?->id ?? auth()->guard('web')->user()?->id;
        $kelasId = $validated['kelas_id'];
        $tanggal = $validated['tanggal'];
        $bulan = (int) date('Ym', strtotime($tanggal));

        // Validasi wali kelas
        if ($guru) {
            $isWaliKelas = Kelas::where('id', $kelasId)->where('guru_id', $guru->id)->exists();
            if (!$isWaliKelas) {
                return response()->json(['error' => 'Anda bukan wali kelas untuk kelas ini.'], 403);
            }
        }

        DB::beginTransaction();
        try {
            // 1. Simpan/Update Jurnal Kelas (info umum)
            JurnalKelas::updateOrCreate(
                ['kelas_id' => $kelasId, 'tanggal' => $tanggal],
                [
                    'semester_id' => $semesterAktif->id,
                    'guru_id' => $guruId,
                    'pertemuan_ke' => $validated['pertemuan_ke'] ?? null,
                    'halaman_juz' => $validated['halaman_juz'] ?? null,
                    'surat_id' => $validated['surat_id'] ?? null,
                    'ayat' => $validated['ayat'] ?? null,
                    'materi_pembelajaran' => $validated['materi_pembelajaran'] ?? null,
                    'topik' => $validated['topik'] ?? null,
                    'rencana' => $validated['rencana'] ?? null,
                    'catatan_kelas' => $validated['catatan_kelas'] ?? null,
                ]
            );

            // 2. Simpan/Update Penilaian per Siswa
            $inserted = 0;
            $updated = 0;

            // Deduplicate entries per siswa_id
            $entriesBySiswa = [];
            foreach ($validated['entries'] as $e) {
                $entriesBySiswa[$e['siswa_id']] = $e;
            }

            foreach ($entriesBySiswa as $siswaId => $e) {
                $existing = JurnalHarian::where('kelas_id', $kelasId)
                    ->where('tanggal', $tanggal)
                    ->where('siswa_id', $siswaId)
                    ->first();

                if ($existing) {
                    $existing->update([
                        'guru_id' => $guruId,
                        'semester_id' => $semesterAktif->id,
                        'penilaian' => $e['penilaian'] ?? null,
                        'catatan' => $e['catatan'] ?? null,
                    ]);
                    $updated++;
                } else {
                    JurnalHarian::create([
                        'semester_id' => $semesterAktif->id,
                        'kelas_id' => $kelasId,
                        'guru_id' => $guruId,
                        'siswa_id' => $siswaId,
                        'tanggal' => $tanggal,
                        'penilaian' => $e['penilaian'] ?? null,
                        'catatan' => $e['catatan'] ?? null,
                    ]);
                    $inserted++;
                }
            }

            // 3. Update rekap bulanan
            $this->updateRekapBulanan($semesterAktif->id, $kelasId, $tanggal);

            DB::commit();
            Cache::forget("rekap_kelas:{$kelasId}:{$bulan}");

            return response()->json([
                'success' => true,
                'message' => "Jurnal tersimpan. {$inserted} baru, {$updated} diperbarui.",
                'inserted' => $inserted,
                'updated' => $updated,
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['error' => 'Gagal menyimpan: ' . $e->getMessage()], 500);
        }
    }

    // ==================== REKAP BULANAN (GURU) ====================
    public function rekapBulanan(Request $request)
    {
        $guru = auth()->guard('web')->user()?->guru ?? null;
        $semesterAktif = Semester::aktif()->first();

        $kelasQuery = Kelas::where('status', 'aktif');
        if ($guru) {
            $kelasQuery->where('guru_id', $guru->id);
        }
        $kelasList = $kelasQuery->orderBy('nama')->get();

        $kelasId = $request->get('kelas_id', $kelasList->first()?->id);
        $bulan = $request->get('bulan', (int) now()->format('Ym'));

        $kelasAktif = $kelasId ? $kelasList->firstWhere('id', $kelasId) : null;
        $siswaList = collect();
        $tanggalList = [];
        $rekapData = [];
        $summaryPerTanggal = [];
        $rataRataKelas = 0;

        if ($kelasAktif) {
            // Semua siswa aktif di kelas ini
            $siswaList = Siswa::where('status', 'aktif')
                ->where('kelas_tartil_id', $kelasId)
                ->with('kelasReguler')
                ->orderBy('nama')
                ->get();

            // Ambil semua tanggal unik di bulan ini yang ada penilaian
            $year = (int) substr($bulan, 0, 4);
            $month = (int) substr($bulan, 4, 2);
            $jurnals = JurnalHarian::where('kelas_id', $kelasId)
                ->whereYear('tanggal', $year)
                ->whereMonth('tanggal', $month)
                ->whereNotNull('penilaian')
                ->select('tanggal', 'siswa_id', 'penilaian')
                ->orderBy('tanggal')
                ->get();

            // Buat daftar tanggal unik
            $uniqueTanggal = $jurnals->pluck('tanggal')->unique()->sort()->values();
            foreach ($uniqueTanggal as $t) {
                $tanggalList[] = [
                    'tanggal' => $t,
                    'tanggal_str' => $t->format('Y-m-d'),
                ];
            }

            // Buat map data: siswa_id -> tanggal -> nilai
            $rekapData = [];
            foreach ($siswaList as $s) {
                $rekapData[$s->id] = ['nilai' => [], 'summary' => ['b_c' => 0, 'k' => 0]];
            }

            foreach ($jurnals as $j) {
                $tStr = $j->tanggal->format('Y-m-d');
                if (isset($rekapData[$j->siswa_id])) {
                    $rekapData[$j->siswa_id]['nilai'][$tStr] = $j->penilaian;
                    if (in_array($j->penilaian, ['B', 'C'])) {
                        $rekapData[$j->siswa_id]['summary']['b_c']++;
                    } elseif ($j->penilaian == 'K') {
                        $rekapData[$j->siswa_id]['summary']['k']++;
                    }
                }
            }

            // Summary per tanggal
            foreach ($tanggalList as $t) {
                $tStr = $t['tanggal_str'];
                $summaryPerTanggal[$tStr] = ['b_c' => 0, 'k' => 0];
                foreach ($jurnals as $j) {
                    if ($j->tanggal->format('Y-m-d') == $tStr) {
                        if (in_array($j->penilaian, ['B', 'C'])) {
                            $summaryPerTanggal[$tStr]['b_c']++;
                        } elseif ($j->penilaian == 'K') {
                            $summaryPerTanggal[$tStr]['k']++;
                        }
                    }
                }
            }

            // Rata-rata kelas
            $totalPersen = 0;
            $siswaCount = $siswaList->count();
            $tglCount = count($tanggalList);
            if ($siswaCount > 0 && $tglCount > 0) {
                foreach ($rekapData as $data) {
                    $totalPersen += round(($data['summary']['b_c'] / $tglCount) * 100);
                }
                $rataRataKelas = round($totalPersen / $siswaCount);
            }
        }

        // Handle Export Excel
        if ($request->has('export') && $request->export === 'excel') {
            $bulanLabel = \Carbon\Carbon::createFromFormat('Ym', $bulan)->locale('id')->isoFormat('MMMM YYYY');

            $export = new \App\Exports\RekapNilaiExport(
                $siswaList, $tanggalList, $rekapData, $summaryPerTanggal,
                $kelasAktif->nama ?? 'Kelas', $bulanLabel
            );
            $spreadsheet = $export->export();

            $filename = 'rekap_nilai_' . str_replace(' ', '_', strtolower($kelasAktif->nama ?? 'kelas')) . '_' . $bulan . '.xlsx';

            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Cache-Control: max-age=0');

            $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
            $writer->save('php://output');
            exit;
        }

        return view('guru.jurnal.rekap', compact(
            'kelasList', 'kelasId', 'bulan', 'kelasAktif',
            'siswaList', 'tanggalList', 'rekapData',
            'summaryPerTanggal', 'rataRataKelas', 'semesterAktif'
        ));
    }

    // ==================== REKAP SEMESTER (ADMIN) ====================
    public function adminRekap(Request $request)
    {
        $semesterId = $request->get('semester_id');
        $kelasId = $request->get('kelas_id');

        $semesters = Semester::orderBy('tanggal_mulai', 'desc')->get();
        $kelasList = Kelas::where('status', 'aktif')->orderBy('nama')->get();

        $rekap = collect();
        if ($semesterId && $kelasId) {
            $cacheKey = "rekap_admin:{$semesterId}:{$kelasId}";
            $rekap = Cache::remember($cacheKey, 3600, function () use ($semesterId, $kelasId) {
                return RekapJurnalBulanan::where('semester_id', $semesterId)
                    ->where('kelas_id', $kelasId)
                    ->with('siswa')
                    ->orderBy('bulan')
                    ->get()
                    ->groupBy('siswa_id');
            });
        }

        return view('admin.jurnal.rekap', compact('semesters', 'kelasList', 'semesterId', 'kelasId', 'rekap'));
    }

    // ==================== PRIVATE: UPDATE REKAP BULANAN ====================
    private function updateRekapBulanan(int $semesterId, int $kelasId, string $tanggal): void
    {
        $bulan = (int) date('Ym', strtotime($tanggal));

        $aggregasi = JurnalHarian::where('semester_id', $semesterId)
            ->where('kelas_id', $kelasId)
            ->whereRaw("YEAR(tanggal) * 100 + MONTH(tanggal) = ?", [$bulan])
            ->select(
                'siswa_id',
                DB::raw('SUM(CASE WHEN penilaian IS NOT NULL THEN 1 ELSE 0 END) as total_hadir'),
                DB::raw('SUM(CASE WHEN penilaian = "B" THEN 1 ELSE 0 END) as count_b'),
                DB::raw('SUM(CASE WHEN penilaian = "C" THEN 1 ELSE 0 END) as count_c'),
                DB::raw('SUM(CASE WHEN penilaian = "K" THEN 1 ELSE 0 END) as count_k'),
            )
            ->groupBy('siswa_id')
            ->get();

        foreach ($aggregasi as $agg) {
            $totalDinilai = $agg->count_b + $agg->count_c + $agg->count_k;
            $rataRata = null;
            if ($totalDinilai > 0) {
                $skor = ($agg->count_b * 1.0 + $agg->count_c * 0.67 + $agg->count_k * 0.33) / $totalDinilai;
                $rataRata = round($skor, 2);
            }

            RekapJurnalBulanan::updateOrCreate(
                ['semester_id' => $semesterId, 'kelas_id' => $kelasId, 'siswa_id' => $agg->siswa_id, 'bulan' => $bulan],
                [
                    'total_hadir' => $agg->total_hadir,
                    'total_izin' => 0,
                    'total_sakit' => 0,
                    'total_alpa' => 0,
                    'count_b' => $agg->count_b,
                    'count_c' => $agg->count_c,
                    'count_k' => $agg->count_k,
                    'rata_rata' => $rataRata,
                ]
            );
        }
    }
}
