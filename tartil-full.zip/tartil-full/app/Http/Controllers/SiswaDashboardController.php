<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\JurnalDetail;
use App\Models\Absensi;
use App\Models\PerpindahanKelas;
use App\Models\Semester;

class SiswaDashboardController extends Controller
{
    public function dashboard()
    {
        $siswa = auth('siswa')->user();
        $semester = Semester::aktif()->first();

        // Statistik nilai semester aktif
        $nilaiSemester = [];
        if ($semester) {
            $nilaiSemester = JurnalDetail::whereHas('jurnal', function($q) use ($semester) {
                $q->where('semester_id', $semester->id);
            })->where('siswa_id', $siswa->id)->get();
        }

        // Absensi semester aktif
        $absensiStats = ['Hadir' => 0, 'Sakit' => 0, 'Izin' => 0, 'Alpha' => 0];
        if ($semester) {
            foreach ($absensiStats as $status => $val) {
                $absensiStats[$status] = Absensi::where('siswa_id', $siswa->id)
                    ->where('status', $status)
                    ->whereHas('jurnal', fn($q) => $q->where('semester_id', $semester->id))
                    ->count();
            }
        }

        return view('siswa.dashboard', compact('siswa', 'nilaiSemester', 'absensiStats', 'semester'));
    }

    public function nilai(Request $request)
    {
        $siswa = auth('siswa')->user();
        $semesters = Semester::orderBy('tahun_ajaran', 'desc')->get();
        
        $semesterId = $request->get('semester', Semester::aktif()->first()?->id);
        
        $nilais = JurnalDetail::where('siswa_id', $siswa->id)
            ->whereHas('jurnal', fn($q) => $q->where('semester_id', $semesterId))
            ->with('jurnal.kelas')
            ->orderBy('created_at', 'desc')
            ->paginate(20);

        return view('siswa.nilai', compact('nilais', 'semesters', 'semesterId'));
    }

    public function absensi(Request $request)
    {
        $siswa = auth('siswa')->user();
        $semesters = Semester::orderBy('tahun_ajaran', 'desc')->get();
        
        $semesterId = $request->get('semester', Semester::aktif()->first()?->id);
        
        $absensis = Absensi::where('siswa_id', $siswa->id)
            ->whereHas('jurnal', fn($q) => $q->where('semester_id', $semesterId))
            ->with(['kelas'])
            ->orderBy('tanggal', 'desc')
            ->paginate(30);

        return view('siswa.absensi', compact('absensis', 'semesters', 'semesterId'));
    }

    public function perpindahan()
    {
        $siswa = auth('siswa')->user();
        $perpindahans = PerpindahanKelas::where('siswa_id', $siswa->id)
            ->with(['kelasLama', 'kelasBaru', 'semester'])
            ->orderBy('created_at', 'desc')
            ->paginate(20);

        return view('siswa.perpindahan', compact('perpindahans'));
    }
}
