<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\UjianMunaqosyah;
use App\Models\MunaqosyahPendaftaran;
use App\Models\MunaqosyahApproval;
use App\Models\Semester;
use App\Models\Siswa;
use App\Models\Kelas;
use Illuminate\Support\Facades\DB;

class MunaqosyahController extends Controller
{
    // ==================== ADMIN: INDEX (LIST UJIAN SAJA) ====================
    public function adminIndex()
    {
        $ujians = UjianMunaqosyah::with(['semester', 'pengaju', 'approver'])
            ->withCount('pendaftarans')
            ->orderBy('created_at', 'desc')->paginate(20);
        $semester = Semester::aktif()->first();
        return view('admin.munaqosyah.index', compact('ujians', 'semester'));
    }

    // ==================== ADMIN: DAFTAR SISWA (3-STEP) ====================
    // Alur: Pilih Ujian → Pilih Kelas Tartil → Checkbox Siswa → Submit
    public function adminDaftar(Request $request)
    {
        $step = 1;
        $ujianTerpilih = null;
        $kelasTerpilih = null;
        $siswaList = collect();

        // List ujian yang disetujui
        $ujianList = UjianMunaqosyah::whereIn('status', ['disetujui', 'sedang_berlangsung'])
            ->with('semester')
            ->orderBy('tanggal_ujian', 'desc')
            ->get();

        // List kelas tartil
        $kelasTartilList = Kelas::where('status', 'aktif')
            ->with('guru')
            ->withCount(['siswas' => fn($q) => $q->where('status', 'aktif')])
            ->orderByRaw("FIELD(jenis, 'BQ 1', 'BQ 2', 'BQ 3', 'BQ 4', 'Tartil', 'Tahfidz')")
            ->orderBy('nama')
            ->get();

        // Step 2: Ujian sudah dipilih, pilih kelas
        if ($request->filled('ujian_id') && $request->filled('kelas_tartil_id')) {
            $ujianTerpilih = UjianMunaqosyah::find($request->ujian_id);
            $kelasTerpilih = Kelas::find($request->kelas_tartil_id);
            if ($ujianTerpilih && $kelasTerpilih) {
                // Ambil semua siswa dari kelas, dengan status pendaftaran
                $sudahTerdaftar = MunaqosyahPendaftaran::where('munaqosyah_id', $ujianTerpilih->id)
                    ->pluck('siswa_id')
                    ->toArray();
                $siswaList = Siswa::where('kelas_tartil_id', $kelasTerpilih->id)
                    ->where('status', 'aktif')
                    ->with('kelasReguler')
                    ->orderBy('nama')
                    ->get()
                    ->map(function($s) use ($sudahTerdaftar) {
                        $s->sudah_terdaftar = in_array($s->id, $sudahTerdaftar);
                        return $s;
                    });
                $step = 2;
            }
        }
        // Step 1: Pilih ujian
        elseif ($request->filled('ujian_id')) {
            $ujianTerpilih = UjianMunaqosyah::find($request->ujian_id);
            $step = 1;
        }

        return view('admin.munaqosyah.daftar', compact(
            'ujianList', 'kelasTartilList', 'ujianTerpilih', 'kelasTerpilih', 'siswaList', 'step'
        ));
    }

    // ==================== ADMIN: SIMPAN DAFTAR SISWA KE UJIAN ====================
    public function adminDaftarSimpan(Request $request)
    {
        $request->validate([
            'ujian_id' => 'required|exists:ujian_munaqosyahs,id',
            'siswa_ids' => 'required|array|min:1',
            'siswa_ids.*' => 'exists:siswas,id',
        ]);

        $ujian = UjianMunaqosyah::find($request->ujian_id);
        $count = 0;
        $skipped = 0;

        foreach ($request->siswa_ids as $siswaId) {
            // Cek apakah siswa sudah pernah daftar ke ujian ini
            $existing = MunaqosyahPendaftaran::where('munaqosyah_id', $ujian->id)
                ->where('siswa_id', $siswaId)
                ->first();
            if ($existing) {
                $skipped++;
                continue;
            }

            $pendaftaran = MunaqosyahPendaftaran::create([
                'munaqosyah_id' => $ujian->id,
                'siswa_id' => $siswaId,
                'diajukan_oleh' => auth()->id(),
                'pengaju_type' => 'admin',
                'status' => 'pending',
                'nilai' => null,
                'catatan' => null,
            ]);
            try {
                MunaqosyahApproval::create([
                    'pendaftaran_id' => $pendaftaran->id,
                    'status' => 'pending',
                    'catatan' => 'Menunggu persetujuan admin',
                ]);
                $count++;
            } catch (\Exception $e) {
                // Kalau approval gagal, tetap lanjut tapi catat error
                $count++;
            }
        }

        $message = "{$count} siswa diajukan ke ujian '{$ujian->nama}'.";
        if ($skipped > 0) {
            $message .= " {$skipped} siswa dilewati karena sudah terdaftar.";
        }
        $message .= " Menunggu approval.";

        return redirect()->route('admin.munaqosyah.daftar')
            ->with('success', $message);
    }

    public function adminDetail(UjianMunaqosyah $munaqosyah)
    {
        $munaqosyah->loadCount([
            'pendaftarans as total_pendaftar' => fn($q) => $q->where('status', '!=', 'pending'),
            'pendaftarans as total_pending' => fn($q) => $q->where('status', 'pending'),
            'pendaftarans as total_lulus' => fn($q) => $q->where('status', 'lulus'),
            'pendaftarans as total_tidak_lulus' => fn($q) => $q->where('status', 'tidak_lulus'),
            'pendaftarans as total_menunggu' => fn($q) => $q->where('status', 'terdaftar'),
        ]);

        return view('admin.munaqosyah.detail', compact('munaqosyah'));
    }

    public function adminStore(Request $request)
    {
        $request->validate([
            'nama' => 'required|max:100',
            'tingkat' => 'required|in:unit,yayasan,pesantren',
            'tanggal_ujian' => 'required|date',
            'semester_id' => 'required|exists:semesters,id',
        ]);

        // Admin buat ujian langsung disetujui
        $ujian = UjianMunaqosyah::create([
            'nama' => $request->nama,
            'tingkat' => $request->tingkat,
            'tanggal_ujian' => $request->tanggal_ujian,
            'semester_id' => $request->semester_id,
            'status' => 'disetujui',
            'diajukan_oleh' => auth()->id(),
            'approved_by' => auth()->id(),
            'approved_at' => now(),
        ]);

        return redirect()->route('admin.munaqosyah.index')
            ->with('success', "Ujian '{$ujian->nama}' berhasil dibuat dan disetujui. Silakan daftarkan siswa melalui menu Daftar Siswa.");
    }

    public function adminApprove(UjianMunaqosyah $munaqosyah)
    {
        $munaqosyah->update([
            'status' => 'disetujui',
            'approved_by' => auth()->id(),
            'approved_at' => now(),
        ]);
        return back()->with('success', 'Ujian munaqosyah disetujui.');
    }

    public function adminTolak(Request $request, UjianMunaqosyah $munaqosyah)
    {
        $munaqosyah->update([
            'status' => 'ditolak',
            'approved_by' => auth()->id(),
            'approved_at' => now(),
            'catatan' => $request->catatan,
        ]);
        return back()->with('success', 'Ujian munaqosyah ditolak.');
    }

    // ==================== ADMIN: DAFTARKAN SISWA (pending approval) ====================
    public function adminDaftarkan(Request $request, UjianMunaqosyah $munaqosyah)
    {
        $request->validate([
            'siswa_ids' => 'required|array|min:1',
            'siswa_ids.*' => 'exists:siswas,id',
        ]);
        foreach ($request->siswa_ids as $siswaId) {
            $pendaftaran = MunaqosyahPendaftaran::firstOrCreate(
                ['munaqosyah_id' => $munaqosyah->id, 'siswa_id' => $siswaId],
                ['status' => 'pending']
            );
            // Pending approval (sama seperti guru)
            MunaqosyahApproval::updateOrCreate(
                ['pendaftaran_id' => $pendaftaran->id],
                ['status' => 'pending', 'catatan' => 'Menunggu persetujuan admin']
            );
        }
        return back()->with('success', count($request->siswa_ids) . ' siswa diajukan. Menunggu approval.');
    }

    // ==================== GURU: APPROVAL REKAP ====================
    public function guruApprovalRekap()
    {
        $guru = auth()->user()?->guru;
        if (!$guru) return back()->with('error', 'Data guru tidak ditemukan untuk akun ini. Hubungi admin.');
        $kelasIds = Kelas::where('guru_id', $guru->id)->pluck('id');

        $pendaftarans = MunaqosyahPendaftaran::with(['munaqosyah', 'siswa', 'pengaju', 'approval'])
            ->whereHas('siswa', function ($q) use ($kelasIds) {
                $q->whereIn('kelas_tartil_id', $kelasIds);
            })
            ->orderBy('created_at', 'desc')
            ->paginate(30);

        return view('guru.munaqosyah.approval-rekap', compact('pendaftarans', 'guru'));
    }

    // ==================== GURU: INDEX ====================
    public function guruIndex()
    {
        // Guru hanya lihat ujian yang sudah disetujui
        $ujians = UjianMunaqosyah::with(['semester'])
            ->where('status', 'disetujui')
            ->orderBy('created_at', 'desc')->paginate(20);
        $semester = Semester::aktif()->first();
        return view('guru.munaqosyah.index', compact('ujians', 'semester'));
    }

    // ==================== GURU: DAFTARKAN SISWA (hanya kelas sendiri, pending approval) ====================
    public function guruDaftarkan(Request $request, UjianMunaqosyah $munaqosyah)
    {
        $request->validate([
            'siswa_ids' => 'required|array|min:1',
            'siswa_ids.*' => 'exists:siswas,id',
        ]);
        $guru = auth()->user()?->guru;
        if (!$guru) return back()->with('error', 'Data guru tidak ditemukan untuk akun ini. Hubungi admin.');
        $kelasIds = Kelas::where('guru_id', $guru->id)->pluck('id');
        $count = 0;

        foreach ($request->siswa_ids as $siswaId) {
            $siswa = Siswa::find($siswaId);
            if (!$kelasIds->contains($siswa->kelas_tartil_id)) {
                return back()->with('error', "Siswa {$siswa->nama} tidak ada di kelas Anda.");
            }
            // Cek apakah siswa sudah pernah daftar ke ujian ini (apapun statusnya)
            $existing = MunaqosyahPendaftaran::where('munaqosyah_id', $munaqosyah->id)
                ->where('siswa_id', $siswaId)
                ->first();
            if ($existing) continue; // skip kalau sudah pernah daftar

            $pendaftaran = MunaqosyahPendaftaran::create([
                'munaqosyah_id' => $munaqosyah->id,
                'siswa_id' => $siswaId,
                'diajukan_oleh' => auth()->id(),
                'pengaju_type' => 'guru',
                'status' => 'pending',
            ]);
            MunaqosyahApproval::create([
                'pendaftaran_id' => $pendaftaran->id,
                'status' => 'pending',
                'catatan' => 'Menunggu persetujuan',
            ]);
            $count++;
        }
        return back()->with('success', $count . ' siswa diajukan. Menunggu approval admin.');
    }

    public function guruDetail(UjianMunaqosyah $munaqosyah)
    {
        $munaqosyah->load(['pendaftarans.siswa', 'semester']);
        // Guru hanya bisa lihat siswa dari kelasnya sendiri untuk didaftarkan
        $guru = auth()->user()?->guru;
        if (!$guru) return back()->with('error', 'Data guru tidak ditemukan untuk akun ini. Hubungi admin.');
        $kelasIds = Kelas::where('guru_id', $guru->id)->pluck('id');
        $siswas = Siswa::whereIn('kelas_tartil_id', $kelasIds)
            ->where('status', 'aktif')
            ->whereNotIn('id', $munaqosyah->pendaftarans->pluck('siswa_id'))
            ->orderBy('nama')->get();
        return view('guru.munaqosyah.detail', compact('munaqosyah', 'siswas'));
    }

    // ==================== GURU: INPUT NILAI (BATCH) ====================
    public function guruNilaiBatch(Request $request, UjianMunaqosyah $munaqosyah)
    {
        $request->validate([
            'nilai' => 'required|array',
            'nilai.*.pendaftaran_id' => 'required|exists:munaqosyah_pendaftarans,id',
            'nilai.*.status' => 'required|in:lulus,tidak_lulus',
            'nilai.*.nilai' => 'nullable|integer|min:0|max:100',
            'nilai.*.catatan' => 'nullable',
        ]);
        DB::beginTransaction();
        try {
            foreach ($request->nilai as $n) {
                $pendaftaran = MunaqosyahPendaftaran::find($n['pendaftaran_id']);
                if ($pendaftaran->munaqosyah_id !== $munaqosyah->id) continue;
                $pendaftaran->update([
                    'status' => $n['status'],
                    'nilai' => $n['nilai'] ?? null,
                    'catatan' => $n['catatan'] ?? null,
                ]);
            }
            DB::commit();
            return back()->with('success', 'Nilai berhasil disimpan.');
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', $e->getMessage());
        }
    }

    // ==================== BATCH: LULUS SEMUA / TIDAK LULUS SEMUA ====================
    public function guruLulusSemua(UjianMunaqosyah $munaqosyah)
    {
        $count = $munaqosyah->pendaftarans()->where('status', 'terdaftar')->update([
            'status' => 'lulus',
        ]);
        return back()->with('success', "{$count} siswa dinyatakan lulus.");
    }

    public function guruTidakLulusSemua(UjianMunaqosyah $munaqosyah)
    {
        $count = $munaqosyah->pendaftarans()->where('status', 'terdaftar')->update([
            'status' => 'tidak_lulus',
        ]);
        return back()->with('success', "{$count} siswa dinyatakan tidak lulus.");
    }

    // ==================== SISWA: LIHAT RIWAYAT ====================
    public function siswaIndex()
    {
        $siswa = auth('siswa')->user();
        $riwayat = MunaqosyahPendaftaran::with(['munaqosyah.semester'])
            ->where('siswa_id', $siswa->id)
            ->orderBy('created_at', 'desc')
            ->paginate(20);
        return view('siswa.munaqosyah', compact('riwayat'));
    }
}
