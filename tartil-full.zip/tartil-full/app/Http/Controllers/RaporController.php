<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Siswa;
use App\Models\Kelas;
use App\Models\Semester;
use App\Models\JurnalDetail;
use App\Models\Absensi;
use Barryvdh\DomPDF\Facade\Pdf;

class RaporController extends Controller
{
    public function pilihKelas()
    {
        $kelas = Kelas::where('status', 'aktif')->orderBy('nama')->get();
        $semesters = Semester::orderBy('tahun_ajaran', 'desc')->get();
        return view('guru.rapor.pilih', compact('kelas', 'semesters'));
    }

    public function previewRaporKelas(Request $request)
    {
        $request->validate([
            'kelas_id' => 'required|exists:kelas,id',
            'semester_id' => 'required|exists:semesters,id',
            'jenis' => 'required|in:tengah,akhir',
        ]);

        $kelas = Kelas::with('guru')->findOrFail($request->kelas_id);
        $semester = Semester::findOrFail($request->semester_id);
        
        $siswas = Siswa::where('kelas_tartil_id', $request->kelas_id)
            ->where('status', 'aktif')->orderBy('nama')->get();

        $dataRapor = [];
        foreach ($siswas as $siswa) {
            $dataRapor[] = $this->hitungRapor($siswa, $request->kelas_id, $request->semester_id, $request->jenis);
        }

        return view('guru.rapor.preview', compact('kelas', 'semester', 'dataRapor', 'siswas'));
    }

    public function pdfRaporSiswa(Request $request)
    {
        $request->validate([
            'siswa_id' => 'required|exists:siswas,id',
            'kelas_id' => 'required|exists:kelas,id',
            'semester_id' => 'required|exists:semesters,id',
            'jenis' => 'required|in:tengah,akhir',
        ]);

        $siswa = Siswa::with(['kelasReguler', 'kelasTartil'])->findOrFail($request->siswa_id);
        $kelas = Kelas::with('guru')->findOrFail($request->kelas_id);
        $semester = Semester::findOrFail($request->semester_id);
        
        $rapor = $this->hitungRapor($siswa, $request->kelas_id, $request->semester_id, $request->jenis);

        $pdf = Pdf::loadView('pdf.rapor-siswa', compact('siswa', 'kelas', 'semester', 'rapor'));
        $filename = "Rapor_{$siswa->nis}_{$semester->tahun_ajaran}_{$semester->jenis}.pdf";
        return $pdf->download($filename);
    }

    public function pdfRaporKelas(Request $request)
    {
        $request->validate([
            'kelas_id' => 'required|exists:kelas,id',
            'semester_id' => 'required|exists:semesters,id',
            'jenis' => 'required|in:tengah,akhir',
        ]);

        $kelas = Kelas::with('guru')->findOrFail($request->kelas_id);
        $semester = Semester::findOrFail($request->semester_id);
        
        $siswas = Siswa::where('kelas_tartil_id', $request->kelas_id)
            ->where('status', 'aktif')->orderBy('nama')->get();

        $dataRapor = [];
        foreach ($siswas as $siswa) {
            $dataRapor[] = $this->hitungRapor($siswa, $request->kelas_id, $request->semester_id, $request->jenis);
        }

        $pdf = Pdf::loadView('pdf.rapor-kelas', compact('kelas', 'semester', 'dataRapor', 'siswas'));
        $filename = "Rapor_Kelas_{$kelas->nama}_{$semester->tahun_ajaran}_{$semester->jenis}.pdf";
        return $pdf->download($filename);
    }

    private function hitungRapor($siswa, $kelasId, $semesterId, $jenis)
    {
        $query = JurnalDetail::where('siswa_id', $siswa->id)
            ->whereHas('jurnal', function($q) use ($kelasId, $semesterId, $jenis) {
                $q->where('kelas_id', $kelasId)
                  ->where('semester_id', $semesterId);
                
                if ($jenis === 'tengah') {
                    $q->where('jenis_penilaian', 'harian');
                }
            });

        $details = $query->get();

        $totalB = $details->sum('nilai_b');
        $totalC = $details->sum('nilai_c');
        $totalK = $details->sum('nilai_k');
        $count = $details->count();

        $rataB = $count > 0 ? round($totalB / $count, 2) : 0;
        $rataC = $count > 0 ? round($totalC / $count, 2) : 0;
        $rataK = $count > 0 ? round($totalK / $count, 2) : 0;
        $rataAkhir = $count > 0 ? round(($rataB + $rataC + $rataK) / 3, 2) : 0;

        $predikat = match(true) {
            $rataAkhir >= 85 => 'A (Sangat Baik)',
            $rataAkhir >= 75 => 'B (Baik)',
            $rataAkhir >= 65 => 'C (Cukup)',
            $rataAkhir >= 50 => 'D (Kurang)',
            default => 'E (Sangat Kurang)',
        };

        // Absensi
        $absensi = [
            'Hadir' => Absensi::where('siswa_id', $siswa->id)->where('status', 'Hadir')
                ->whereHas('jurnal', fn($q) => $q->where('semester_id', $semesterId))->count(),
            'Sakit' => Absensi::where('siswa_id', $siswa->id)->where('status', 'Sakit')
                ->whereHas('jurnal', fn($q) => $q->where('semester_id', $semesterId))->count(),
            'Izin' => Absensi::where('siswa_id', $siswa->id)->where('status', 'Izin')
                ->whereHas('jurnal', fn($q) => $q->where('semester_id', $semesterId))->count(),
            'Alpha' => Absensi::where('siswa_id', $siswa->id)->where('status', 'Alpha')
                ->whereHas('jurnal', fn($q) => $q->where('semester_id', $semesterId))->count(),
        ];
        $totalPertemuan = array_sum($absensi);
        $persentaseHadir = $totalPertemuan > 0 ? round(($absensi['Hadir'] / $totalPertemuan) * 100, 2) : 0;

        return [
            'siswa' => $siswa,
            'jumlah_penilaian' => $count,
            'rata_b' => $rataB,
            'rata_c' => $rataC,
            'rata_k' => $rataK,
            'rata_akhir' => $rataAkhir,
            'predikat' => $predikat,
            'absensi' => $absensi,
            'total_pertemuan' => $totalPertemuan,
            'persentase_hadir' => $persentaseHadir,
            'details' => $details,
        ];
    }
}
