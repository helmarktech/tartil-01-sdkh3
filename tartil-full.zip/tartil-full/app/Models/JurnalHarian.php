<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Cache;

class JurnalHarian extends Model
{
    protected $table = 'jurnal_harians';
    protected $fillable = [
        'semester_id', 'kelas_id', 'guru_id', 'siswa_id', 'tanggal',
        'kehadiran', 'penilaian', 'surat_id', 'ayat_mulai', 'ayat_selesai', 'catatan',
    ];

    /**
     * PENILAIAN: B = Baik, C = Cukup, K = Kurang
     * Kehadiran tersirat dari penilaian: ada penilaian = hadir
     */
    protected $casts = [
        'tanggal' => 'date',
        'ayat_mulai' => 'integer',
        'ayat_selesai' => 'integer',
    ];

    // ================= RELATIONS =================
    public function semester()
    {
        return $this->belongsTo(Semester::class);
    }

    public function kelas()
    {
        return $this->belongsTo(Kelas::class);
    }

    public function guru()
    {
        return $this->belongsTo(GuruTartil::class, 'guru_id');
    }

    public function siswa()
    {
        return $this->belongsTo(Siswa::class);
    }

    public function surat()
    {
        return $this->belongsTo(Surat::class);
    }

    // ================= HELPERS =================
    public static function kehadiranLabel(int $k): string
    {
        return match($k) {
            1 => 'Hadir',
            2 => 'Izin',
            3 => 'Sakit',
            default => 'Alpa',
        };
    }

    public static function kehadiranBadge(int $k): string
    {
        return match($k) {
            1 => 'badge-success',
            2 => 'badge-info',
            3 => 'badge-warning',
            default => 'badge-error',
        };
    }

    public static function penilaianLabel(?string $p): string
    {
        return match($p) {
            'B' => 'Baik',
            'C' => 'Cukup',
            'K' => 'Kurang',
            default => '-',
        };
    }

    public static function penilaianBadge(?string $p): string
    {
        return match($p) {
            'B' => 'badge-success',
            'C' => 'badge-warning',
            'K' => 'badge-error',
            default => 'badge-muted',
        };
    }

    // ================= SCOPE =================
    public function scopeHadir($q)
    {
        return $q->where('kehadiran', 1);
    }

    public function scopeTidakHadir($q)
    {
        return $q->whereIn('kehadiran', [0, 2, 3]);
    }

    public function scopeDinilai($q)
    {
        return $q->whereNotNull('penilaian');
    }

    public function scopeByKelasTanggal($q, int $kelasId, string $tanggal)
    {
        return $q->where('kelas_id', $kelasId)->where('tanggal', $tanggal);
    }

    // ================= CACHE INVALIDATION =================
    protected static function boot()
    {
        parent::boot();
        static::saved(function ($jurnal) {
            Cache::forget("rekap_kelas:{$jurnal->kelas_id}:" . str_replace('-', '', $jurnal->tanggal->format('Y-m')));
        });
        static::deleted(function ($jurnal) {
            Cache::forget("rekap_kelas:{$jurnal->kelas_id}:" . str_replace('-', '', $jurnal->tanggal->format('Y-m')));
        });
    }
}
