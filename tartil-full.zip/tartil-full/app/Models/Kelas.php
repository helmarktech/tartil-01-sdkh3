<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Kelas extends Model
{
    protected $table = 'kelas';
    protected $fillable = [
        'nama', 'jenis', 'mata_pelajaran', 'deskripsi', 'hari',
        'jam_mulai', 'jam_selesai', 'guru_id', 'status'
    ];
    protected $casts = [
        'jam_mulai' => 'datetime:H:i',
        'jam_selesai' => 'datetime:H:i',
    ];

    public function guru()
    {
        return $this->belongsTo(Guru::class);
    }

    public function siswas()
    {
        return $this->hasMany(Siswa::class, 'kelas_tartil_id');
    }

    public function jurnals()
    {
        return $this->hasMany(Jurnal::class);
    }

    public function absensis()
    {
        return $this->hasMany(Absensi::class);
    }

    public function scopeAktif($query)
    {
        return $query->where('status', 'aktif');
    }
}
