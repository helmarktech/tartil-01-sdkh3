<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UjianMunaqosyah extends Model
{
    protected $table = 'ujian_munaqosyahs';
    protected $fillable = [
        'nama', 'tingkat', 'tanggal_ujian', 'semester_id',
        'status', 'diajukan_oleh', 'approved_by', 'approved_at', 'catatan'
    ];
    protected $casts = [
        'tanggal_ujian' => 'date',
        'approved_at' => 'datetime',
    ];

    public function semester()
    {
        return $this->belongsTo(Semester::class);
    }

    public function pengaju()
    {
        return $this->belongsTo(Guru::class, 'diajukan_oleh');
    }

    public function approver()
    {
        return $this->belongsTo(User::class, 'approved_by');
    }

    public function pendaftarans()
    {
        return $this->hasMany(MunaqosyahPendaftaran::class, 'munaqosyah_id');
    }

    public function scopePendingApproval($query)
    {
        return $query->where('status', 'pengajuan');
    }

    public function scopeAktif($query)
    {
        return $query->whereIn('status', ['disetujui', 'sedang_berlangsung']);
    }

    public function jumlahLulus(): int
    {
        return $this->pendaftarans()->where('status', 'lulus')->count();
    }

    public function jumlahTidakLulus(): int
    {
        return $this->pendaftarans()->where('status', 'tidak_lulus')->count();
    }

    public function jumlahTerdaftar(): int
    {
        return $this->pendaftarans()->where('status', 'terdaftar')->count();
    }

    public function persentaseKelulusan(): float
    {
        $total = $this->pendaftarans()->count();
        if ($total == 0) return 0;
        return round(($this->jumlahLulus() / $total) * 100, 2);
    }
}
