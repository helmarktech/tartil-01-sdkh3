<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MunaqosyahPendaftaran extends Model
{
    protected $table = 'munaqosyah_pendaftarans';
    protected $fillable = ['munaqosyah_id', 'siswa_id', 'diajukan_oleh', 'pengaju_type', 'status', 'nilai', 'catatan'];

    public function munaqosyah()
    {
        return $this->belongsTo(UjianMunaqosyah::class, 'munaqosyah_id');
    }

    public function siswa()
    {
        return $this->belongsTo(Siswa::class);
    }

    public function pengaju()
    {
        return $this->belongsTo(User::class, 'diajukan_oleh');
    }

    public function approval()
    {
        return $this->hasOne(MunaqosyahApproval::class, 'pendaftaran_id');
    }

    public function scopeTerdaftar($query)
    {
        return $query->where('status', 'terdaftar');
    }

    public function scopeSudahDinilai($query)
    {
        return $query->whereIn('status', ['lulus', 'tidak_lulus']);
    }

    public function scopeDisetujui($query)
    {
        return $query->whereHas('approval', fn($q) => $q->where('status', 'disetujui'));
    }

    public function scopePendingApproval($query)
    {
        return $query->whereHas('approval', fn($q) => $q->where('status', 'pending'));
    }

    public function getStatusApprovalAttribute(): string
    {
        return $this->approval?->status ?? 'pending';
    }
}
