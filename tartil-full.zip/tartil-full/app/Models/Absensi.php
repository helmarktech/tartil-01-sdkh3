<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Absensi extends Model
{
    protected $table = 'absensis';
    protected $fillable = [
        'tanggal', 'siswa_id', 'kelas_id', 'jurnal_id', 'status', 'keterangan'
    ];
    protected $casts = ['tanggal' => 'date'];

    public function siswa()
    {
        return $this->belongsTo(Siswa::class);
    }

    public function kelas()
    {
        return $this->belongsTo(Kelas::class);
    }

    public function jurnal()
    {
        return $this->belongsTo(Jurnal::class);
    }

    public function scopeHadir($query)
    {
        return $query->where('status', 'Hadir');
    }

    public function scopeBySemester($query, $semesterId)
    {
        return $query->whereHas('jurnal', fn($q) => $q->where('semester_id', $semesterId));
    }
}
